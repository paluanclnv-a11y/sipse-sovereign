# SIPSE Sovereign Financial Network (SSFN) v1.0

Un'applicazione web full-stack realistica per l'ecosistema finanziario sovrano **SIPSE**. Questo progetto implementa completamente il sistema descritto su [sipsesovereign.org](https://sipsesovereign.org/).

## 🏛️ Moduli Principali Implementati

| Modulo | Descrizione |
|--------|-------------|
| **P-ISO Central Authority (PICA)** | Autorità monetaria centrale con controllo su emissione e ritiro di token |
| **P-ISO Sovereign Exchange (PSX)** | Exchange di 15 valute sovrani basate su risorse reali |
| **People's Natural Resources Exchange (PNRX)** | Mercato di 12 asset naturali (acqua, litio, rame, oro, ecc.) |
| **Sovereign Population Registry (SPR)** | Registro demografico con 127 popoli aderenti rappresentanti 482M persone |
| **SIPSE Global Reserve System (SGRS)** | Sistema di riserve con ancoraggio a beni reali (oro, acqua, energia, foreste) |
| **SIPSE Digital Wallet Network** | Portafoglio digitale simulato con saldi token |
| **SIPSE Governance AI Engine** | Motore di governance con proposte e votazioni comunitarie |

## 📊 Statistiche di Sistema

- **Popoli aderenti iniziali**: 127
- **Popolazione rappresentata**: 482.000.000
- **Indice sovrano medio**: 83,6/100
- **Riserve iniziali PSD**: 4.5 Trilioni §P
- **Target inflazione**: 2%
- **Target volatilità**: 4,5%

## 🚀 API Endpoints

### `/api/sipse-state` (GET)
Ritorna lo stato completo dell'ecosistema:
```json
{
  "success": true,
  "currencies": [...],
  "nations": [...],
  "balances": [...],
  "orders": [...],
  "proposals": [...],
  "priceHistory": [...],
  "metrics": {...}
}
```

### `/api/sipse-state` (POST)
Esegue azioni sul network:
- `action: "buy_sell"` - Acquista/vendi asset
- `action: "register_nation"` - Registra nuova comunità
- `action: "vote_proposal"` - Vota proposte di governance
- `action: "create_proposal"` - Crea nuova proposta
- `action: "mint_burn"` - Operazioni monetarie PICA
- `action: "simulate_tick"` - Ricalcolo algoritmo AI
- `action: "reset"` - Resetta database

### `/api/embed` (GET)
Endpoint ottimizzato per integrazione cross-origin:
- `?type=ticker` - Dati ticker per widget
- `?type=metrics` - Metriche di sistema
- `?type=proposals` - Proposte attive
- `?type=chart&currency=AQS` - Storico prezzi per grafici

### `/api/sse` (GET)
Server-Sent Events per aggiornamenti in tempo reale.

## 🔌 Integrazione WordPress

### Shortcode Generator
Genera shortcode personalizzabili per il sito sipsesovereign.org:

```
[piso_exchange theme="dark" limit="5" show_chart="true"]
[pnrx_exchange theme="light" limit="10"]
[sipse_dashboard theme="gold" show_map="true"]
```

### JavaScript Widget
Per integrare il widget direttamente in qualsiasi pagina:

```html
<script src="https://YOUR-DOMAIN.com/sipse-widget.js" 
        data-theme="dark" 
        data-limit="10">
</script>
```

## 🛠️ Tecnologie Utilizzate

- **Next.js 16** (App Router)
- **React 19** (Client Components)
- **Drizzle ORM** (PostgreSQL)
- **Tailwind CSS 4** (Styling)
- **Lucide React** (Icone)

## 📋 Disclaimer Legale

> Le quotazioni SIPSE rappresentano valori ufficiali interni dell'ecosistema SIPSE Sovereign e non costituiscono strumenti finanziari regolamentati o quotazioni dei mercati internazionali.

## 🚀 Avvio Rapido

```bash
# Installare le dipendenze
npm install

# Applicare lo schema al database
npx drizzle-kit push

# Avviare il server di sviluppo
npm run dev
```

## 📡 Collegamento a sipsesovereign.org

Questa applicazione è progettata per essere integrata con il portale principale [sipsesovereign.org](https://sipsesovereign.org/). Gli endpoint API sono dotati di CORS headers per consentire richieste cross-origin dal dominio principale.

### Percorso di Integrazione Consigliato

1. **Widget JavaScript** - Inserire lo script in footer del tema WordPress
2. **Shortcode** - Utilizzare i shortcode generati nel contenuto delle pagine
3. **API REST** - Interrogare `/api/embed` per dati in tempo reale
4. **SSE** - Per notifiche push in tempo reale (richiede configurazione server-side)

---

**SIPSE Sovereign Financial Network (SSFN) v1.0** - Tutti i diritti riservati ai popoli aderenti.