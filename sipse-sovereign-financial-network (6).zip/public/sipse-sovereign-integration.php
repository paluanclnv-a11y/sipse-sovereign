<?php
/**
 * Plugin Name: SIPSE Sovereign Ecosystem Integration Hub
 * Plugin URI: https://sipsesovereign.org
 * Description: Collegamento sicuro e performante per l'Ecosistema Finanziario Sovrano SSFN v1.0. Include Shortcode, Enqueueing automatico, validazione di sicurezza Bearer JWT e CORS policy.
 * Version: 1.0.0
 * Author: SIPSE Sovereign Dev Team
 * Author URI: https://sipsesovereign.org
 * License: GPL2
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// 1. CONFIGURAZIONE DEI PARAMETRI DI SICUREZZA
define('SIPSE_API_SECRET_KEY', 'SOVEREIGN_SECRET_JWT_KEY_2026_CHANGE_ME'); // Chiave per firmare/verificare i token JWT
define('SIPSE_APP_EXTERNAL_URL', 'https://3000-itv3pphd7aanxpjvf7hoz.e2b.app'); // Indirizzo dell'App React

// 2. ENQUEUE DEI FILE COMPILATI (JS e CSS)
function enqueue_sipse_dashboard_assets() {
    // Registra ed include i file del build di produzione React
    wp_enqueue_script(
        'sipse-app', 
        SIPSE_APP_EXTERNAL_URL . '/_next/static/chunks/main-app.js', // Sostituire con l'indirizzo esatto del bundle compilato
        array(), 
        '1.0.0', 
        true
    );
    
    wp_enqueue_style(
        'sipse-style', 
        SIPSE_APP_EXTERNAL_URL . '/_next/static/css/app.css', // Sostituire con l'indirizzo esatto del file CSS
        array(), 
        '1.0.0'
    );
}
add_action('wp_enqueue_scripts', 'enqueue_sipse_dashboard_assets');


// 3. DEFINIZIONE DELLO SHORTCODE [piso_exchange]
function sipse_piso_exchange_shortcode($atts) {
    $a = shortcode_atts(array(
        'theme' => 'dark',
        'limit' => '5',
        'show_chart' => 'true'
    ), $atts);

    // Contenitore HTML in cui l'App React eseguirà il rendering
    return sprintf(
        '<div id="sipse-piso-exchange-root" data-theme="%s" data-limit="%s" data-chart="%s">
            <div style="text-align:center; padding:30px; font-family:sans-serif; color:#94a3b8;">
                <p>Connessione sicura all\'Ecosistema SIPSE Sovereign in corso...</p>
            </div>
         </div>',
        esc_attr($a['theme']),
        esc_attr($a['limit']),
        esc_attr($a['show_chart'])
    );
}
add_shortcode('piso_exchange', 'sipse_piso_exchange_shortcode');


// 4. DEFINIZIONE DELLO SHORTCODE [pnrx_exchange]
function sipse_pnrx_exchange_shortcode($atts) {
    $a = shortcode_atts(array(
        'theme' => 'dark',
        'limit' => '8'
    ), $atts);

    return sprintf(
        '<div id="sipse-pnrx-exchange-root" data-theme="%s" data-limit="%s">
            <div style="text-align:center; padding:30px; font-family:sans-serif; color:#94a3b8;">
                <p>Caricamento People\'s Natural Resources Exchange...</p>
            </div>
         </div>',
        esc_attr($a['theme']),
        esc_attr($a['limit'])
    );
}
add_shortcode('pnrx_exchange', 'sipse_pnrx_exchange_shortcode');


// 5. DEFINIZIONE DELLO SHORTCODE [sipse_dashboard]
function sipse_dashboard_shortcode($atts) {
    $a = shortcode_atts(array(
        'theme' => 'dark',
        'show_map' => 'true'
    ), $atts);

    return sprintf(
        '<div id="sipse-dashboard-root" data-theme="%s" data-map="%s">
            <div style="text-align:center; padding:30px; font-family:sans-serif; color:#94a3b8;">
                <p>Caricamento SIPSE Sovereign Dashboard v1.0...</p>
            </div>
         </div>',
        esc_attr($a['theme']),
        esc_attr($a['show_map'])
    );
}
add_shortcode('sipse_dashboard', 'sipse_dashboard_shortcode');


// 6. GESTIONE DELLA SICUREZZA (CORS, HTTPS, VALIDAZIONE JWT)
// Configura le CORS policy per proteggere il dialogo tra sipsesovereign.org ed il server API
function sipse_configure_cors_policies() {
    $allowed_origins = array(
        'https://sipsesovereign.org',
        'https://app.sipsesovereign.org',
        'https://3000-itv3pphd7aanxpjvf7hoz.e2b.app'
    );

    if (isset($_SERVER['HTTP_ORIGIN'])) {
        $origin = $_SERVER['HTTP_ORIGIN'];
        if (in_array($origin, $allowed_origins)) {
            header("Access-Control-Allow-Origin: " . esc_url_raw($origin));
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
            header("Access-Control-Allow-Headers: Content-Type, Authorization");
            header("Access-Control-Allow-Credentials: true");
        }
    }
    
    // Obbligatorietà di HTTPS
    if (!is_ssl() && $_SERVER['REQUEST_METHOD'] !== 'OPTIONS') {
        wp_die('Errore di Sicurezza: SIPSE Sovereign Financial Network richiede HTTPS per tutte le comunicazioni.', 'Errore SSL', 403);
    }
}
add_action('init', 'sipse_configure_cors_policies');


// 7. PROXY API SICURO CON VERIFICA DEL JWT TOKEN
// Questo proxy intercetta le chiamate critiche (come Mint/Burn o Proposte)
// e valida la presenza dell'header 'Authorization: Bearer <JWT>'
add_action('rest_api_init', function () {
    register_rest_route('sipse/v1', '/secure-action', array(
        'methods' => 'POST',
        'callback' => 'sipse_handle_secure_api_action',
        'permission_callback' => 'sipse_validate_jwt_token_permission'
    ));
});

// Controllo dei permessi: verifica il Bearer Token
function sipse_validate_jwt_token_permission($request) {
    $auth_header = $request->get_header('Authorization');
    
    if (!$auth_header || strpos($auth_header, 'Bearer ') !== 0) {
        return new WP_Error('rest_forbidden', 'Errore di Sicurezza: Token Bearer mancante o formato non valido.', array('status' => 401));
    }

    $token = substr($auth_header, 7); // Rimuove 'Bearer '
    
    // Validazione del token (Decodifica simmetrica con la chiave segreta)
    $is_valid = sipse_verify_offline_jwt($token);
    
    if (!$is_valid) {
        return new WP_Error('rest_forbidden', 'Errore di Sicurezza: Token JWT non valido o scaduto.', array('status' => 403));
    }

    return true; // Utente autorizzato, procedi con l'azione
}

// Handler per l'azione sicura
function sipse_handle_secure_api_action($request) {
    $params = $request->get_json_params();
    
    // Inoltro sicuro dei dati all'App centrale SSFN
    $response = wp_remote_post(SIPSE_APP_EXTERNAL_URL . '/api/sipse-state', array(
        'headers' => array(
            'Content-Type' => 'application/json',
            'Authorization' => $request->get_header('Authorization')
        ),
        'body' => json_encode($params),
        'timeout' => 15
    ));

    if (is_wp_error($response)) {
        return new WP_REST_Response(array('success' => false, 'error' => $response->get_error_message()), 500);
    }

    $body = wp_remote_retrieve_body($response);
    return new WP_REST_Response(json_decode($body, true), 200);
}

// Funzione helper offline per la verifica del JWT (Senza dipendenze esterne per massima compatibilità)
function sipse_verify_offline_jwt($token) {
    $parts = explode('.', $token);
    if (count($parts) !== 3) {
        return false;
    }

    list($header64, $payload64, $signature) = $parts;
    
    // Verifica firma HMAC SHA256
    $expected_signature = hash_hmac('sha256', "$header64.$payload64", SIPSE_API_SECRET_KEY, true);
    $expected_signature_base64 = str_replace(array('+', '/', '='), array('-', '_', ''), base64_encode($expected_signature));

    if ($signature !== $expected_signature_base64) {
        return false; // Firma non valida
    }

    $payload = json_decode(base64_decode($payload64), true);
    
    // Verifica scadenza token (Expiration Time)
    if (isset($payload['exp']) && $payload['exp'] < time()) {
        return false; // Token scaduto
    }

    return true;
}
