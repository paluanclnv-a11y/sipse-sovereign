// SIPSE Sovereign Financial Network - Live Widget for sipsesovereign.org
// Usage: <script src="https://YOUR-DOMAIN.com/sipse-widget.js" data-theme="dark" data-limit="10"></script>

(function() {
  const script = document.currentScript;
  const theme = script.getAttribute('data-theme') || 'dark';
  const limit = parseInt(script.getAttribute('data-limit') || '10');
  const apiUrl = script.getAttribute('data-api') || 'https://YOUR-DOMAIN.com/api/embed';

  // Create widget container
  const container = document.createElement('div');
  container.id = 'sipse-widget';
  container.style.cssText = `
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: ${theme === 'light' ? '#f8f9fa' : '#070e0a'};
    color: ${theme === 'light' ? '#1a1a1a' : '#e2e8f0'};
    border: 1px solid ${theme === 'light' ? '#dee2e6' : '#0e2617'};
    border-radius: 8px;
    padding: 16px;
    max-width: 400px;
    margin: 16px auto;
  `;

  // Add header
  const header = document.createElement('div');
  header.innerHTML = `
    <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 12px; border-bottom: 1px solid ${theme === 'light' ? '#dee2e6' : '#0e2617'}; padding-bottom: 8px;">
      <span style="display: inline-block; width: 10px; height: 10px; background: #10b981; border-radius: 50%; animation: pulse 2s infinite;"></span>
      <span style="font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; color: ${theme === 'light' ? '#0f88ff' : '#fbbf24'};">
        SIPSE Sovereign Network
      </span>
    </div>
    <style>
      @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }
    </style>
  `;
  container.appendChild(header);

  // Add metrics container
  const metricsDiv = document.createElement('div');
  metricsDiv.id = 'sipse-metrics';
  container.appendChild(metricsDiv);

  // Add loading state
  metricsDiv.innerHTML = '<div style="text-align: center; padding: 20px; font-size: 14px;">Caricamento dati...</div>';

  // Fetch data and render
  fetch(apiUrl + '?type=metrics&theme=' + theme)
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        metricsDiv.innerHTML = `
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; font-size: 13px;">
            <div style="background: ${theme === 'light' ? '#ffffff' : '#0b1410'}; padding: 12px; border-radius: 6px; border: 1px solid ${theme === 'light' ? '#e9ecef' : '#0e2617'};">
              <div style="color: ${theme === 'light' ? '#6c757d' : '#94a3b8'}; font-size: 10px; text-transform: uppercase; margin-bottom: 4px;">Popoli Aderenti</div>
              <div style="font-weight: 700; font-size: 18px; color: ${theme === 'light' ? '#0f88ff' : '#fbbf24'};">${data.metrics.nationsCount}</div>
            </div>
            <div style="background: ${theme === 'light' ? '#ffffff' : '#0b1410'}; padding: 12px; border-radius: 6px; border: 1px solid ${theme === 'light' ? '#e9ecef' : '#0e2617'};">
              <div style="color: ${theme === 'light' ? '#6c757d' : '#94a3b8'}; font-size: 10px; text-transform: uppercase; margin-bottom: 4px;">Popolazione</div>
              <div style="font-weight: 700; font-size: 16px; color: ${theme === 'light' ? '#0f88ff' : '#10b981'};">${data.metrics.population.toLocaleString()}</div>
            </div>
            <div style="background: ${theme === 'light' ? '#ffffff' : '#0b1410'}; padding: 12px; border-radius: 6px; border: 1px solid ${theme === 'light' ? '#e9ecef' : '#0e2617'};">
              <div style="color: ${theme === 'light' ? '#6c757d' : '#94a3b8'}; font-size: 10px; text-transform: uppercase; margin-bottom: 4px;">Indice Sovrano</div>
              <div style="font-weight: 700; font-size: 18px; color: ${theme === 'light' ? '#0f88ff' : '#fbbf24'};">${data.metrics.sovereignIndex}/100</div>
            </div>
            <div style="background: ${theme === 'light' ? '#ffffff' : '#0b1410'}; padding: 12px; border-radius: 6px; border: 1px solid ${theme === 'light' ? '#e9ecef' : '#0e2617'};">
              <div style="color: ${theme === 'light' ? '#6c757d' : '#94a3b8'}; font-size: 10px; text-transform: uppercase; margin-bottom: 4px;">Riserve Globali</div>
              <div style="font-weight: 700; font-size: 16px; color: ${theme === 'light' ? '#0f88ff' : '#10b981'};">${(data.metrics.reserves / 1e12).toFixed(1)}T §P</div>
            </div>
          </div>
          <div style="margin-top: 12px; text-align: center; font-size: 10px; color: ${theme === 'light' ? '#6c757d' : '#64748b'};">
            Dati in tempo reale da <a href="https://sipsesovereign.org/" target="_blank" style="color: ${theme === 'light' ? '#0f88ff' : '#10b981'}; text-decoration: none;">sipsesovereign.org</a>
          </div>
        `;
      } else {
        metricsDiv.innerHTML = '<div style="color: #ef4444; text-align: center; padding: 20px;">Errore nel caricamento dati</div>';
      }
    })
    .catch(err => {
      metricsDiv.innerHTML = '<div style="color: #ef4444; text-align: center; padding: 20px;">Errore di connessione</div>';
      console.error('SIPSE Widget Error:', err);
    });

  // Insert into page
  if (script.parentNode) {
    script.parentNode.insertBefore(container, script);
  }
})();