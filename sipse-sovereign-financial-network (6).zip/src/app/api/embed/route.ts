import { NextResponse } from 'next/server';
import { db } from '@/db';
import { currencies, sovereignNations, governanceProposals, priceHistory } from '@/db/schema';
import { seedIfEmpty } from '@/db/seed-data';
import { desc } from 'drizzle-orm';

// CORS headers for cross-origin integration with sipsesovereign.org
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Content-Type': 'application/json',
};

// GET: Fetch embeddable data for external sites
export async function GET(req: Request) {
  try {
    await seedIfEmpty();

    const url = new URL(req.url);
    const type = url.searchParams.get('type') || 'ticker';
    const limit = parseInt(url.searchParams.get('limit') || '10');
    const theme = url.searchParams.get('theme') || 'dark';

    const allCurrencies = await db.select().from(currencies);
    const allNations = await db.select().from(sovereignNations).orderBy(desc(sovereignNations.createdAt));
    const recentHistory = await db.select().from(priceHistory).orderBy(desc(priceHistory.timestamp)).limit(100);

    let totalPopulation = 0;
    let sumSovereignIndex = 0;
    allNations.forEach(n => {
      totalPopulation += n.population;
      sumSovereignIndex += parseFloat(n.sovereignIndex.toString() || '0');
    });

    const avgSovereignIndex = allNations.length > 0 ? (sumSovereignIndex / allNations.length) : 83.6;
    const displayPopulation = Math.max(482000000, totalPopulation);

    let responseData: any = { success: true, type, theme };

    switch (type) {
      case 'ticker':
        // Return simplified ticker data for live scrolling display
        responseData.currencies = allCurrencies.slice(0, limit).map(c => ({
          code: c.code,
          name: c.name,
          value: parseFloat(c.valuePsd),
          change: parseFloat(c.changePercent)
        }));
        break;

      case 'metrics':
        // Return key metrics for dashboard widgets
        responseData.metrics = {
          nationsCount: 127 + Math.max(0, allNations.length - 19),
          population: displayPopulation,
          sovereignIndex: parseFloat(avgSovereignIndex.toFixed(2)),
          reserves: 4500000000000,
          inflationTarget: 2.0,
          volatilityTarget: 4.5
        };
        break;

      case 'proposals':
        // Return active governance proposals
        const allProposals = await db.select().from(governanceProposals);
        responseData.proposals = allProposals.filter(p => p.status === 'ACTIVE').slice(0, limit);
        break;

      case 'chart':
        // Return price history for charting
        const currencyCode = url.searchParams.get('currency') || 'AQS';
        responseData.currency = currencyCode;
        responseData.history = recentHistory
          .filter(h => h.currencyCode === currencyCode)
          .map(h => ({
            price: parseFloat(h.price),
            timestamp: h.timestamp
          }));
        break;
    }

    return NextResponse.json(responseData, { headers: corsHeaders });
  } catch (error: any) {
    console.error('Error in embed endpoint:', error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500, headers: corsHeaders });
  }
}

// OPTIONS: Handle CORS preflight
export async function OPTIONS() {
  return new NextResponse(null, { status: 204, headers: corsHeaders });
}