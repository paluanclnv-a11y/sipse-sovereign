import { NextResponse } from 'next/server';
import { db } from '@/db';
import { currencies, sovereignNations, walletBalances, orders, governanceProposals, priceHistory } from '@/db/schema';
import { seedIfEmpty } from '@/db/seed-data';
import { eq, and, sql, desc } from 'drizzle-orm';

// CORS headers for cross-origin integration with sipsesovereign.org
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  'Content-Type': 'application/json',
};

// GET: Fetch complete state
export async function GET() {
  try {
    // 1. Seed if empty
    await seedIfEmpty();

    // 2. Fetch all data
    const allCurrencies = await db.select().from(currencies);
    const allNations = await db.select().from(sovereignNations).orderBy(desc(sovereignNations.createdAt));
    const allBalances = await db.select().from(walletBalances);
    const allOrders = await db.select().from(orders).orderBy(desc(orders.createdAt)).limit(50);
    const allProposals = await db.select().from(governanceProposals).orderBy(desc(governanceProposals.createdAt));
    
    // Fetch recent price history
    const recentHistory = await db.select().from(priceHistory).orderBy(desc(priceHistory.timestamp)).limit(150);

    // Calculate aggregated metrics
    let totalPopulation = 0;
    let sumSovereignIndex = 0;
    allNations.forEach(n => {
      totalPopulation += n.population;
      sumSovereignIndex += parseFloat(n.sovereignIndex.toString() || '0');
    });

    const avgSovereignIndex = allNations.length > 0 ? (sumSovereignIndex / allNations.length) : 83.6;

    // Static baseline for initial populations in countries not in DB (total population is 482M as requested)
    const displayPopulation = Math.max(482000000, totalPopulation);

    return NextResponse.json({
      success: true,
      currencies: allCurrencies,
      nations: allNations,
      balances: allBalances,
      orders: allOrders,
      proposals: allProposals,
      priceHistory: recentHistory,
      metrics: {
        totalNationsCount: 127 + Math.max(0, allNations.length - 19),
        registeredNationsCount: allNations.length,
        representedPopulation: displayPopulation,
        avgSovereignIndex: parseFloat(avgSovereignIndex.toFixed(2)),
        initialReservesPsd: 4500000000000,
        inflationTarget: 2.0,
        volatilityTarget: 4.5,
      }
    }, { headers: corsHeaders });
  } catch (error: any) {
    console.error('Error fetching SIPSE state:', error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500, headers: corsHeaders });
  }
}

// OPTIONS: Handle CORS preflight
export async function OPTIONS() {
  return new NextResponse(null, { status: 204, headers: corsHeaders });
}

// POST: Execute action
export async function POST(req: Request) {
  try {
    await seedIfEmpty();
    const body = await req.json();
    const { action, ...payload } = body;

    if (!action) {
      return NextResponse.json({ success: false, error: 'No action specified' }, { status: 400 });
    }

    const walletAddress = payload.walletAddress || 'SIPSE-SOV-7719-2026';

    switch (action) {
      case 'reset': {
        // Clear all tables
        await db.delete(priceHistory);
        await db.delete(orders);
        await db.delete(walletBalances);
        await db.delete(governanceProposals);
        await db.delete(sovereignNations);
        await db.delete(currencies);

        // Reseed
        await seedIfEmpty();

        return NextResponse.json({ success: true, message: 'Database reset and seeded successfully' });
      }

      case 'buy_sell': {
        const { type, currencyCode, amount: rawAmount } = payload;
        const amount = parseFloat(rawAmount);

        if (!currencyCode || isNaN(amount) || amount <= 0) {
          return NextResponse.json({ success: false, error: 'Invalid currency or amount' }, { status: 400 });
        }

        // Get the currency rate
        const [curr] = await db.select().from(currencies).where(eq(currencies.code, currencyCode)).limit(1);
        if (!curr) {
          return NextResponse.json({ success: false, error: 'Currency not found' }, { status: 404 });
        }

        const pricePsd = parseFloat(curr.valuePsd.toString());
        const totalCostPsd = amount * pricePsd;

        // Fetch wallet balances
        const balances = await db.select().from(walletBalances).where(eq(walletBalances.walletAddress, walletAddress));
        const psdBalanceObj = balances.find(b => b.currencyCode === 'PSD');
        const currBalanceObj = balances.find(b => b.currencyCode === currencyCode);

        const currentPsdBalance = psdBalanceObj ? parseFloat(psdBalanceObj.balance.toString()) : 0;
        const currentCurrBalance = currBalanceObj ? parseFloat(currBalanceObj.balance.toString()) : 0;

        if (type === 'BUY') {
          // Check if user has enough PSD
          if (currentPsdBalance < totalCostPsd) {
            return NextResponse.json({ success: false, error: 'Saldo PSD insufficiente per completare l acquisto' }, { status: 400 });
          }

          // Deduct PSD
          if (psdBalanceObj) {
            await db.update(walletBalances)
              .set({ balance: (currentPsdBalance - totalCostPsd).toFixed(4), updatedAt: new Date() })
              .where(and(eq(walletBalances.walletAddress, walletAddress), eq(walletBalances.currencyCode, 'PSD')));
          } else {
            // Should not happen as PSD is default, but handle fallback
            await db.insert(walletBalances).values({
              walletAddress,
              currencyCode: 'PSD',
              balance: (10000 - totalCostPsd).toFixed(4)
            });
          }

          // Add targeted currency
          if (currBalanceObj) {
            await db.update(walletBalances)
              .set({ balance: (currentCurrBalance + amount).toFixed(4), updatedAt: new Date() })
              .where(and(eq(walletBalances.walletAddress, walletAddress), eq(walletBalances.currencyCode, currencyCode)));
          } else {
            await db.insert(walletBalances).values({
              walletAddress,
              currencyCode,
              balance: amount.toFixed(4)
            });
          }

          // Simulate demand price increase (+0.25% per 100 units purchased)
          const multiplier = 1 + (0.0025 * Math.min(5, amount / 100));
          const newPrice = (pricePsd * multiplier).toFixed(4);
          const originalPrice = parseFloat(curr.originalValue.toString());
          const changePct = (((parseFloat(newPrice) - originalPrice) / originalPrice) * 100).toFixed(2);

          await db.update(currencies)
            .set({ valuePsd: newPrice, changePercent: changePct, lastUpdated: new Date() })
            .where(eq(currencies.code, currencyCode));

          // Log historical tick
          await db.insert(priceHistory).values({
            currencyCode,
            price: newPrice,
          });

        } else if (type === 'SELL') {
          // Selling the target currency to earn PSD
          if (currentCurrBalance < amount) {
            return NextResponse.json({ success: false, error: `Saldo di ${currencyCode} insufficiente per la vendita` }, { status: 400 });
          }

          // Deduct target currency
          await db.update(walletBalances)
            .set({ balance: (currentCurrBalance - amount).toFixed(4), updatedAt: new Date() })
            .where(and(eq(walletBalances.walletAddress, walletAddress), eq(walletBalances.currencyCode, currencyCode)));

          // Add PSD
          if (psdBalanceObj) {
            await db.update(walletBalances)
              .set({ balance: (currentPsdBalance + totalCostPsd).toFixed(4), updatedAt: new Date() })
              .where(and(eq(walletBalances.walletAddress, walletAddress), eq(walletBalances.currencyCode, 'PSD')));
          } else {
            await db.insert(walletBalances).values({
              walletAddress,
              currencyCode: 'PSD',
              balance: totalCostPsd.toFixed(4)
            });
          }

          // Simulate selling pressure price drop (-0.2% per 100 units sold)
          const multiplier = Math.max(0.7, 1 - (0.0020 * Math.min(5, amount / 100)));
          const newPrice = (pricePsd * multiplier).toFixed(4);
          const originalPrice = parseFloat(curr.originalValue.toString());
          const changePct = (((parseFloat(newPrice) - originalPrice) / originalPrice) * 100).toFixed(2);

          await db.update(currencies)
            .set({ valuePsd: newPrice, changePercent: changePct, lastUpdated: new Date() })
            .where(eq(currencies.code, currencyCode));

          // Log historical tick
          await db.insert(priceHistory).values({
            currencyCode,
            price: newPrice,
          });
        } else {
          return NextResponse.json({ success: false, error: 'Invalid order type' }, { status: 400 });
        }

        // Insert order record
        await db.insert(orders).values({
          walletAddress,
          type,
          currencyCode,
          amount: amount.toFixed(4),
          pricePsd: pricePsd.toFixed(4),
          totalPsd: totalCostPsd.toFixed(4),
        });

        return NextResponse.json({ success: true, message: 'Ordine completato ed eseguito nel network sovrano!' });
      }

      case 'register_nation': {
        const { name, region, population, growthRate, sovereignIndex, description } = payload;
        if (!name || !region || !population) {
          return NextResponse.json({ success: false, error: 'Campi obbligatori mancanti' }, { status: 400 });
        }

        await db.insert(sovereignNations).values({
          name,
          region,
          population: parseInt(population),
          growthRate: growthRate || '2.10',
          sovereignIndex: sovereignIndex || '83.60',
          description: description || '',
        });

        return NextResponse.json({ success: true, message: 'Popolo Sovrano registrato correttamente nel registro demografico SPR!' });
      }

      case 'vote_proposal': {
        const { proposalId, voteType } = payload;
        if (!proposalId || !voteType) {
          return NextResponse.json({ success: false, error: 'Proposal ID and voteType are required' }, { status: 400 });
        }

        const [existing] = await db.select().from(governanceProposals).where(eq(governanceProposals.id, proposalId)).limit(1);
        if (!existing) {
          return NextResponse.json({ success: false, error: 'Proposal not found' }, { status: 404 });
        }

        // Generate a random community weight to simulate collective vote
        const voteWeight = Math.floor(Math.random() * 2500) + 500;

        if (voteType === 'for') {
          await db.update(governanceProposals)
            .set({ votesFor: existing.votesFor + voteWeight })
            .where(eq(governanceProposals.id, proposalId));
        } else {
          await db.update(governanceProposals)
            .set({ votesAgainst: existing.votesAgainst + voteWeight })
            .where(eq(governanceProposals.id, proposalId));
        }

        // Auto pass if votes are high
        const updatedVotesFor = existing.votesFor + voteWeight;
        if (updatedVotesFor > 35000 && existing.status === 'ACTIVE') {
          await db.update(governanceProposals)
            .set({ status: 'PASSED' })
            .where(eq(governanceProposals.id, proposalId));
        }

        return NextResponse.json({ success: true, message: `Voto registrato con peso demografico di +${voteWeight} votanti!` });
      }

      case 'create_proposal': {
        const { title, description, proposer, impactMetric } = payload;
        if (!title || !description || !proposer) {
          return NextResponse.json({ success: false, error: 'Campi obbligatori mancanti' }, { status: 400 });
        }

        await db.insert(governanceProposals).values({
          title,
          description,
          proposer,
          status: 'ACTIVE',
          votesFor: Math.floor(Math.random() * 3000) + 1000,
          votesAgainst: Math.floor(Math.random() * 800),
          impactMetric: impactMetric || 'Neutral eco-financial impact',
        });

        return NextResponse.json({ success: true, message: 'Nuova proposta inviata con successo al SIPSE Governance AI Engine!' });
      }

      case 'mint_burn': {
        const { currencyCode, type, amount: rawAmount } = payload;
        const amount = parseFloat(rawAmount);

        if (!currencyCode || isNaN(amount) || amount <= 0) {
          return NextResponse.json({ success: false, error: 'Invalid currency or amount' }, { status: 400 });
        }

        const [curr] = await db.select().from(currencies).where(eq(currencies.code, currencyCode)).limit(1);
        if (!curr) {
          return NextResponse.json({ success: false, error: 'Currency not found' }, { status: 404 });
        }

        const currentCap = curr.capPsd || 100000000;
        const newCap = type === 'MINT' ? (currentCap + amount) : Math.max(1000000, currentCap - amount);

        // Update cap in database
        await db.update(currencies)
          .set({ capPsd: newCap, lastUpdated: new Date() })
          .where(eq(currencies.code, currencyCode));

        // Add audit transaction in orders
        await db.insert(orders).values({
          walletAddress: 'SIPSE-PICA-CENTRAL',
          type: type,
          currencyCode,
          amount: amount.toFixed(4),
          pricePsd: curr.valuePsd,
          totalPsd: (amount * parseFloat(curr.valuePsd.toString())).toFixed(4),
        });

        return NextResponse.json({ success: true, message: `PICA Central Authority: ${type === 'MINT' ? 'Emessi' : 'Ritirati'} ${amount.toLocaleString()} ${currencyCode} con successo.` });
      }

      case 'simulate_tick': {
        // Run the official SIPSE algorithm update!
        // Inputs can include customized multiplier overrides from sliders (e.g. user simulated higher Demand or resources)
        const userResources = parseFloat(payload.resourcesOverride || '1.0');
        const userProduction = parseFloat(payload.productionOverride || '1.0');
        const userDemand = parseFloat(payload.demandOverride || '1.0');
        const userStability = parseFloat(payload.stabilityOverride || '1.0');

        // Let's grab all currencies
        const allCurrencies = await db.select().from(currencies);

        // Core algorithm parameters
        const resourcesCoef = (1.0 + (Math.random() - 0.5) * 0.04) * userResources;
        const productionCoef = (1.0 + (Math.random() - 0.5) * 0.03) * userProduction;
        const demandCoef = (1.0 + (Math.random() - 0.5) * 0.05) * userDemand;
        const stabilityCoef = (1.0 + (Math.random() - 0.5) * 0.02) * userStability;
        const populationCoef = 1.021; // 2.1% population growth factor

        // Money Supply factor: slightly counteracts positive growth to simulate inflation/deflation
        const moneySupplyCoef = 1.0 + (Math.random() - 0.5) * 0.01;

        // SIPSE Official Algorithm Value Formula:
        // Coefficient of adjustment = (Resources * Production * Demand * Stability * Population) / MoneySupply
        const globalAdjustment = (resourcesCoef * productionCoef * demandCoef * stabilityCoef * populationCoef) / moneySupplyCoef;

        // Apply to all currencies and resources
        for (const curr of allCurrencies) {
          const currentPrice = parseFloat(curr.valuePsd.toString());
          const originalPrice = parseFloat(curr.originalValue.toString());
          
          // Each asset has its own small random variance
          const assetVariance = 1.0 + (Math.random() - 0.5) * 0.015;
          const targetAdjustment = globalAdjustment * assetVariance;
          
          // New calculated price
          const newPriceRaw = currentPrice * targetAdjustment;
          // Impose realistic caps/floors so it does not degrade to 0 or infinite
          const finalPrice = Math.max(originalPrice * 0.4, Math.min(originalPrice * 4, newPriceRaw));
          
          const newPriceStr = finalPrice.toFixed(4);
          const changePct = (((finalPrice - originalPrice) / originalPrice) * 100).toFixed(2);

          await db.update(currencies)
            .set({
              valuePsd: newPriceStr,
              changePercent: changePct,
              lastUpdated: new Date()
            })
            .where(eq(currencies.code, curr.code));

          // Log price history tick
          await db.insert(priceHistory).values({
            currencyCode: curr.code,
            price: newPriceStr,
          });
        }

        return NextResponse.json({
          success: true,
          message: 'Algoritmo SIPSE Sovrano eseguito con successo! Ricalcolati i parametri di tutti i 27 asset.',
          globalAdjustment: globalAdjustment.toFixed(4)
        });
      }

      default:
        return NextResponse.json({ success: false, error: 'Unknown action' }, { status: 400 });
    }
  } catch (error: any) {
    console.error('Error in POST action:', error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
