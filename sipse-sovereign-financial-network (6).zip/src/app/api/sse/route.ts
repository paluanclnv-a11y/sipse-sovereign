import { NextResponse } from 'next/server';
import { db } from '@/db';
import { currencies, priceHistory } from '@/db/schema';
import { seedIfEmpty } from '@/db/seed-data';
import { desc } from 'drizzle-orm';

// SSE endpoint for real-time updates to sipsesovereign.org
export async function GET(req: Request) {
  const url = new URL(req.url);
  const channel = url.searchParams.get('channel') || 'prices';

  // Set CORS headers for sipsesovereign.org integration
  const headers = {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET',
    'Access-Control-Allow-Headers': 'Content-Type',
  };

  const stream = new ReadableStream({
    async start(controller) {
      // Send initial connection message
      controller.enqueue(`data: ${JSON.stringify({ type: 'connected', channel, timestamp: new Date().toISOString() })}\n\n`);

      // Send initial data
      try {
        await seedIfEmpty();
        const allCurrencies = await db.select().from(currencies);
        
        if (channel === 'prices') {
          controller.enqueue(`data: ${JSON.stringify({ 
            type: 'prices', 
            data: allCurrencies.map(c => ({
              code: c.code,
              value: parseFloat(c.valuePsd),
              change: parseFloat(c.changePercent)
            }))
          })}\n\n`);
        }
      } catch (error) {
        controller.enqueue(`data: ${JSON.stringify({ type: 'error', message: 'Failed to fetch initial data' })}\n\n`);
      }

      // Send heartbeat every 30 seconds
      const heartbeat = setInterval(() => {
        controller.enqueue(`: heartbeat\n\n`);
      }, 30000);

      // Cleanup on close
      const cleanup = () => {
        clearInterval(heartbeat);
        controller.close();
      };

      // Store cleanup for later
      (req as any).signal?.addEventListener('abort', cleanup);
    }
  });

  return new NextResponse(stream, { headers });
}