import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "SIPSE Sovereign Financial Network (SSFN) - Ecosystem v1.0",
  description: "Rete finanziaria sovrana basata su risorse reali, densità demografica, stabilità biologica e riserve naturali certificate. Collegata a sipsesovereign.org",
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    title: "SIPSE SSFN",
    statusBarStyle: "black-translucent",
  },
};

export const viewport: Viewport = {
  themeColor: "#070e0a",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="it">
      <body className="bg-[#070e0a] text-slate-100 antialiased min-h-screen">
        {children}
      </body>
    </html>
  );
}
