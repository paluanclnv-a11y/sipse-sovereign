'use client';

import React, { useState, useEffect } from 'react';
import { 
  Coins, 
  Globe, 
  TrendingUp, 
  TrendingDown, 
  Users, 
  ShieldCheck, 
  Database, 
  Activity, 
  Wallet, 
  PlusCircle, 
  Code, 
  FileCode, 
  ArrowLeftRight, 
  Sliders, 
  Cpu, 
  RefreshCw, 
  Copy, 
  Check, 
  Award,
  Search,
  Lock,
  Trash2,
  Download,
  ChevronRight,
  HelpCircle
} from 'lucide-react';

interface Currency {
  code: string;
  name: string;
  category: string;
  baseAsset: string;
  valuePsd: string;
  capPsd: number | null;
  originalValue: string;
  changePercent: string;
  lastUpdated: string;
}

interface Nation {
  id: number;
  name: string;
  region: string;
  population: number;
  growthRate: string;
  sovereignIndex: string;
  description: string;
}

interface Order {
  id: number;
  walletAddress: string;
  type: string;
  currencyCode: string;
  amount: string;
  pricePsd: string;
  totalPsd: string;
  createdAt: string;
}

interface Proposal {
  id: number;
  title: string;
  description: string;
  proposer: string;
  status: string;
  votesFor: number;
  votesAgainst: number;
  impactMetric: string;
  createdAt: string;
}

interface PriceTick {
  id: number;
  currencyCode: string;
  price: string;
  timestamp: string;
}

interface SipseState {
  currencies: Currency[];
  nations: Nation[];
  balances: { currencyCode: string; balance: string }[];
  orders: Order[];
  proposals: Proposal[];
  priceHistory: PriceTick[];
  metrics: {
    totalNationsCount: number;
    representedPopulation: number;
    avgSovereignIndex: number;
    initialReservesPsd: number;
    inflationTarget: number;
    volatilityTarget: number;
  };
}

export default function SSFNDashboard() {
  // System state
  const [state, setState] = useState<SipseState | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'exchange' | 'governance' | 'registry' | 'authority' | 'shortcodes' | 'api'>('exchange');

  // User wallet simulation
  const userWalletAddress = 'SIPSE-SOV-7719-2026';
  
  // Interaction states - Exchange
  const [selectedAssetCode, setSelectedAssetCode] = useState<string>('AQS');
  const [tradeType, setTradeType] = useState<'BUY' | 'SELL'>('BUY');
  const [tradeAmount, setTradeAmount] = useState<string>('10');
  const [tradeStatus, setTradeStatus] = useState<{ type: 'success' | 'error' | null; message: string }>({ type: null, message: '' });

  // Interaction states - AI Formula Sliders
  const [sliderResources, setSliderResources] = useState<number>(1.0);
  const [sliderProduction, setSliderProduction] = useState<number>(1.0);
  const [sliderDemand, setSliderDemand] = useState<number>(1.0);
  const [sliderStability, setSliderStability] = useState<number>(1.0);
  const [isSimulatingTick, setIsSimulatingTick] = useState(false);
  const [autoSimulation, setAutoSimulation] = useState(true);
  const [simCountdown, setSimCountdown] = useState(15);

  // Interaction states - Governance Proposals
  const [newPropTitle, setNewPropTitle] = useState('');
  const [newPropDesc, setNewPropDesc] = useState('');
  const [newPropProposer, setNewPropProposer] = useState('');
  const [newPropImpact, setNewPropImpact] = useState('');
  const [propStatusMsg, setPropStatusMsg] = useState('');

  // Interaction states - SPR (Sovereign Population Registry)
  const [nationSearch, setNationSearch] = useState('');
  const [nationRegionFilter, setNationRegionFilter] = useState('ALL');
  const [newNationName, setNewNationName] = useState('');
  const [newNationRegion, setNewNationRegion] = useState('Africa');
  const [newNationPopulation, setNewNationPopulation] = useState('1500000');
  const [newNationGrowth, setNewNationGrowth] = useState('2.1');
  const [newNationIndex, setNewNationIndex] = useState('85');
  const [newNationDesc, setNewNationDesc] = useState('');
  const [nationStatusMsg, setNationStatusMsg] = useState('');

  // Interaction states - PICA Central Mint/Burn
  const [picaAssetCode, setPicaAssetCode] = useState('AQS');
  const [picaActionType, setPicaActionType] = useState<'MINT' | 'BURN'>('MINT');
  const [picaAmount, setPicaAmount] = useState('1000000');
  const [picaStatusMsg, setPicaStatusMsg] = useState('');

  // Interaction states - WordPress Shortcode generator
  const [selectedShortcode, setSelectedShortcode] = useState<'[piso_exchange]' | '[pnrx_exchange]' | '[sipse_dashboard]'>('[piso_exchange]');
  const [scTheme, setScTheme] = useState<'dark' | 'light' | 'gold'>('dark');
  const [scLimit, setScLimit] = useState<number>(5);
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedMasterApp, setCopiedMasterApp] = useState(false);

  // Notification Feed (recent live events)
  const [feedEvents, setFeedEvents] = useState<string[]>([
    'Ecosistema SIPSE SOVEREIGN v1.0 caricato online.',
    'Formula di calcolo P-ISO agganciata alle riserve auree e risorse idriche.',
    'Registro Demografico Sovrano SPR inizializzato con 127 popoli aderenti.'
  ]);

  const addFeedEvent = (msg: string) => {
    setFeedEvents(prev => [msg, ...prev.slice(0, 15)]);
  };

  // Load state from API
  const fetchState = async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const res = await fetch('/api/sipse-state');
      const data = await res.json();
      if (data.success) {
        setState(data);
        setError(null);
      } else {
        setError(data.error || 'Errore durante il recupero dei dati.');
      }
    } catch (err: any) {
      setError(err.message || 'Errore di connessione al server.');
    } finally {
      if (!silent) setLoading(false);
    }
  };

  // Initial load
  useEffect(() => {
    fetchState();
  }, []);

  // 15 seconds Auto-simulation Loop
  useEffect(() => {
    let timer: any;
    if (autoSimulation) {
      timer = setInterval(() => {
        setSimCountdown(prev => {
          if (prev <= 1) {
            triggerFormulaTick();
            return 15;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      setSimCountdown(15);
    }
    return () => clearInterval(timer);
  }, [autoSimulation, sliderResources, sliderProduction, sliderDemand, sliderStability]);

  // Execute simulation tick
  const triggerFormulaTick = async () => {
    setIsSimulatingTick(true);
    try {
      const res = await fetch('/api/sipse-state', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'simulate_tick',
          resourcesOverride: sliderResources,
          productionOverride: sliderProduction,
          demandOverride: sliderDemand,
          stabilityOverride: sliderStability
        })
      });
      const data = await res.json();
      if (data.success) {
        await fetchState(true);
        addFeedEvent(`Algoritmo SIPSE eseguito: Adeguamento globale ${data.globalAdjustment}x basato sui parametri correnti.`);
      }
    } catch (err) {
      console.error('Simulation tick error:', err);
    } finally {
      setIsSimulatingTick(false);
    }
  };

  // Execute Order (Buy / Sell)
  const handleExecuteTrade = async (e: React.FormEvent) => {
    e.preventDefault();
    setTradeStatus({ type: null, message: '' });

    if (!state) return;
    const amountNum = parseFloat(tradeAmount);
    if (isNaN(amountNum) || amountNum <= 0) {
      setTradeStatus({ type: 'error', message: 'Inserire un importo valido superiore a zero.' });
      return;
    }

    try {
      const res = await fetch('/api/sipse-state', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'buy_sell',
          walletAddress: userWalletAddress,
          type: tradeType,
          currencyCode: selectedAssetCode,
          amount: tradeAmount
        })
      });
      const data = await res.json();

      if (data.success) {
        setTradeStatus({ type: 'success', message: data.message });
        addFeedEvent(`Transazione completata: ${tradeType} ${tradeAmount} ${selectedAssetCode} ad un prezzo basato in PSD.`);
        fetchState(true);
      } else {
        setTradeStatus({ type: 'error', message: data.error || 'Errore nell esecuzione dell ordine.' });
      }
    } catch (err: any) {
      setTradeStatus({ type: 'error', message: err.message || 'Errore di rete.' });
    }
  };

  // Register New Nation (SPR)
  const handleRegisterNation = async (e: React.FormEvent) => {
    e.preventDefault();
    setNationStatusMsg('');
    if (!newNationName || !newNationPopulation) {
      setNationStatusMsg('Compilare i campi obbligatori (Nome e Popolazione)');
      return;
    }

    try {
      const res = await fetch('/api/sipse-state', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'register_nation',
          name: newNationName,
          region: newNationRegion,
          population: newNationPopulation,
          growthRate: newNationGrowth,
          sovereignIndex: newNationIndex,
          description: newNationDesc
        })
      });
      const data = await res.json();

      if (data.success) {
        setNationStatusMsg('Popolo Sovrano registrato correttamente con inserimento in database!');
        addFeedEvent(`Nuovo popolo registrato: ${newNationName} (Regione: ${newNationRegion})`);
        
        setNewNationName('');
        setNewNationDesc('');
        setNewNationPopulation('1500000');
        
        fetchState(true);
      } else {
        setNationStatusMsg(data.error || 'Errore nella registrazione');
      }
    } catch (err: any) {
      setNationStatusMsg(err.message || 'Errore di rete');
    }
  };

  // Vote on proposal
  const handleVote = async (proposalId: number, voteType: 'for' | 'against') => {
    try {
      const res = await fetch('/api/sipse-state', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'vote_proposal',
          proposalId,
          voteType
        })
      });
      const data = await res.json();
      if (data.success) {
        addFeedEvent(`Votato Proposta #${proposalId}: ${voteType === 'for' ? 'A favore' : 'Contro'}. ${data.message}`);
        fetchState(true);
      }
    } catch (err: any) {
      console.error('Error voting:', err);
    }
  };

  // Submit custom proposal
  const handleCreateProposal = async (e: React.FormEvent) => {
    e.preventDefault();
    setPropStatusMsg('');
    if (!newPropTitle || !newPropDesc || !newPropProposer) {
      setPropStatusMsg('Inserire Titolo, Proponente e Descrizione.');
      return;
    }

    try {
      const res = await fetch('/api/sipse-state', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'create_proposal',
          title: newPropTitle,
          description: newPropDesc,
          proposer: newPropProposer,
          impactMetric: newPropImpact || 'Eco-Sovereign Equilibrium Boost'
        })
      });
      const data = await res.json();
      if (data.success) {
        setPropStatusMsg('Proposta pubblicata ed entrata in fase di voto attivo!');
        addFeedEvent(`Nuova proposta di governance inviata da ${newPropProposer}: ${newPropTitle}`);
        setNewPropTitle('');
        setNewPropDesc('');
        setNewPropProposer('');
        setNewPropImpact('');
        fetchState(true);
      } else {
        setPropStatusMsg(data.error || 'Errore durante l invio della proposta.');
      }
    } catch (err: any) {
      setPropStatusMsg(err.message || 'Errore di rete.');
    }
  };

  // PICA Mint / Burn simulated operations
  const handlePicaOperation = async (e: React.FormEvent) => {
    e.preventDefault();
    setPicaStatusMsg('');
    try {
      const res = await fetch('/api/sipse-state', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'mint_burn',
          currencyCode: picaAssetCode,
          type: picaActionType,
          amount: picaAmount
        })
      });
      const data = await res.json();
      if (data.success) {
        setPicaStatusMsg(data.message);
        addFeedEvent(`Politica Monetaria PICA: ${picaActionType} di ${parseFloat(picaAmount).toLocaleString()} ${picaAssetCode}`);
        fetchState(true);
      } else {
        setPicaStatusMsg(data.error || 'Errore durante l operazione monetaria.');
      }
    } catch (err: any) {
      setPicaStatusMsg(err.message || 'Errore di rete.');
    }
  };

  // Reset database state to seed
  const handleResetSystem = async () => {
    if (confirm('Sei sicuro di voler ripristinare il database allo stato iniziale del seed? Tutte le transazioni e i nuovi popoli inseriti saranno sovrascritti.')) {
      setLoading(true);
      try {
        const res = await fetch('/api/sipse-state', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'reset' })
        });
        const data = await res.json();
        if (data.success) {
          addFeedEvent('Database resettato e reinizializzato con i parametri originali.');
          await fetchState(false);
        }
      } catch (err) {
        console.error('Reset error:', err);
      } finally {
        setLoading(false);
      }
    }
  };

  // Compile and download single-file standalone offline HTML Web App
  const downloadOfflineApp = () => {
    const defaultCurrencies = state?.currencies || [];
    const defaultNations = state?.nations || [];

    const offlineTemplate = `<!DOCTYPE html>
<html lang="it">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SIPSE Sovereign Financial Network (SSFN) - Standalone Offline App</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body { background-color: #070e0a; color: #f1f5f9; }
    .no-scrollbar::-webkit-scrollbar { display: none; }
    .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
  </style>
</head>
<body class="font-sans min-h-screen">
  
  <!-- Ticker -->
  <div class="bg-[#0b1610] border-b border-emerald-950 text-xs py-2 overflow-hidden sticky top-0 z-50">
    <div class="max-w-6xl mx-auto px-4 flex items-center justify-between gap-4">
      <div class="text-amber-400 font-bold shrink-0">SIPSE OFFLINE EXCHANGES:</div>
      <div class="flex gap-6 overflow-x-auto no-scrollbar whitespace-nowrap text-slate-300 w-full" id="ticker-container">
        <!-- Rendered dynamically -->
      </div>
    </div>
  </div>

  <div class="bg-gradient-to-r from-amber-500/10 to-emerald-500/10 border-b border-emerald-900/50 py-1.5 text-center text-[11px] text-amber-300">
    ⚡ Questa è la versione Standalone scaricabile direttamente. Funziona al 100% offline salvando i dati sul tuo dispositivo locale.
  </div>

  <header class="max-w-6xl mx-auto px-4 py-8">
    <div class="bg-gradient-to-b from-[#0b1610] to-[#070e0a] border border-emerald-950 p-6 rounded-2xl">
      <span class="bg-emerald-500/20 text-emerald-400 text-[10px] font-bold uppercase tracking-widest px-3 py-1 rounded-full">
        SIPSE Sovereign Ecosystem v1.0
      </span>
      <h1 class="text-2xl md:text-3xl font-extrabold mt-3">
        SIPSE Sovereign Financial Network (SSFN)
      </h1>
      <p class="text-slate-400 text-sm mt-2">
        Un'applicazione decentralizzata per la gestione, lo scambio e la pianificazione finanziaria dei popoli sovrani. Ancorata a sipsesovereign.org.
      </p>
    </div>

    <!-- Quick stats -->
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
      <div class="bg-[#0b140f] border border-emerald-950 p-4 rounded-xl">
        <div class="text-xs text-slate-400 uppercase">Popoli Aderenti</div>
        <div class="text-xl font-bold text-slate-100 font-mono mt-1" id="stat-nations">127</div>
      </div>
      <div class="bg-[#0b140f] border border-emerald-950 p-4 rounded-xl">
        <div class="text-xs text-slate-400 uppercase">Popolazione Totale</div>
        <div class="text-xl font-bold text-slate-100 font-mono mt-1">482,000,000</div>
      </div>
      <div class="bg-[#0b140f] border border-emerald-950 p-4 rounded-xl">
        <div class="text-xs text-slate-400 uppercase">Indice Sovrano</div>
        <div class="text-xl font-bold text-amber-400 font-mono mt-1">83.6/100</div>
      </div>
      <div class="bg-[#0b140f] border border-amber-500/20 p-4 rounded-xl">
        <div class="text-xs text-amber-300 uppercase">Il Tuo Saldo PSD</div>
        <div class="text-xl font-bold text-amber-400 font-mono mt-1" id="stat-balance">§P 12,500.00</div>
      </div>
    </div>

    <!-- Interactive Grid -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
      
      <!-- Left side: Currencies -->
      <div class="lg:col-span-2 space-y-6">
        <div class="bg-[#0b1410] border border-emerald-950 rounded-xl p-5">
          <h2 class="text-sm font-bold text-amber-400 uppercase tracking-widest border-b border-emerald-950 pb-2 mb-4">
            Esegui Operazioni (PSX & PNRX)
          </h2>
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            <div>
              <label class="block text-xs text-slate-400 mb-1 font-bold">Seleziona Asset</label>
              <select id="trade-asset" class="w-full bg-[#050907] border border-emerald-900 rounded p-2 text-sm text-slate-100 font-mono">
                ${defaultCurrencies.map(c => `<option value="${c.code}" data-price="${c.valuePsd}">${c.code} - ${c.name} (§P ${parseFloat(c.valuePsd).toFixed(2)})</option>`).join('')}
              </select>
            </div>

            <div>
              <label class="block text-xs text-slate-400 mb-1 font-bold">Tipo Ordine</label>
              <select id="trade-type" class="w-full bg-[#050907] border border-emerald-900 rounded p-2 text-sm text-slate-100 font-mono">
                <option value="BUY">ACQUISTA (BUY)</option>
                <option value="SELL">VENDI (SELL)</option>
              </select>
            </div>

            <div class="md:col-span-2">
              <label class="block text-xs text-slate-400 mb-1 font-bold">Quantità da scambiare</label>
              <input type="number" id="trade-amount" value="10" min="1" class="w-full bg-[#050907] border border-emerald-900 rounded p-2 text-sm font-mono text-slate-100">
            </div>

          </div>

          <button onclick="executeTrade()" class="w-full mt-4 bg-amber-400 hover:bg-amber-500 text-black py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all">
            Invia Ordine Sovrano Offline
          </button>
          <div id="trade-feedback" class="mt-3 text-xs text-center font-bold"></div>
        </div>

        <!-- Nations Directory -->
        <div class="bg-[#0b1410] border border-emerald-950 rounded-xl p-5">
          <h2 class="text-sm font-bold text-slate-300 uppercase tracking-widest border-b border-emerald-950 pb-2 mb-4">
            Registro Demografico SPR (Offline)
          </h2>
          <div class="space-y-3 max-h-[300px] overflow-y-auto pr-1" id="nations-list">
            <!-- Dynamically populated -->
          </div>
        </div>

      </div>

      <!-- Right side: Sidebar info -->
      <div class="lg:col-span-1 space-y-6">
        
        <div class="bg-[#0b1410] border border-emerald-950 rounded-xl p-5">
          <h3 class="text-xs font-bold uppercase text-slate-400 mb-3">I Tuoi Bilanci Token</h3>
          <div class="space-y-2 text-xs" id="balances-list">
            <!-- Dynamically populated -->
          </div>
        </div>

        <div class="bg-[#0b1410] border border-emerald-950 rounded-xl p-5">
          <h3 class="text-xs font-bold uppercase text-slate-400 mb-3">Log Transazioni Offline</h3>
          <div class="space-y-2 text-[11px] font-mono text-slate-400 max-h-[200px] overflow-y-auto" id="orders-log">
            <!-- Logs -->
          </div>
        </div>

      </div>

    </div>
  </header>

  <footer class="max-w-6xl mx-auto px-4 py-8 text-center text-xs text-slate-500 border-t border-emerald-950 mt-12">
    <p>© 2026 SIPSE Sovereign Financial Network (SSFN). Tutti i diritti sono riservati.</p>
    <p class="mt-1">Integrazione sipsesovereign.org</p>
  </footer>

  <script>
    // Initialize Local Storage or default values
    let currencies = ${JSON.stringify(defaultCurrencies)};
    let nations = ${JSON.stringify(defaultNations)};
    
    let balancePsd = parseFloat(localStorage.getItem('offline_balance_psd') || '12500');
    let userBalances = JSON.parse(localStorage.getItem('offline_balances') || '{}');
    let ordersLog = JSON.parse(localStorage.getItem('offline_orders_log') || '[]');

    function saveState() {
      localStorage.setItem('offline_balance_psd', balancePsd.toString());
      localStorage.setItem('offline_balances', JSON.stringify(userBalances));
      localStorage.setItem('offline_orders_log', JSON.stringify(ordersLog));
    }

    function updateUi() {
      // Update stats
      document.getElementById('stat-nations').innerText = nations.length + (127 - nations.length);
      document.getElementById('stat-balance').innerText = '§P ' + balancePsd.toLocaleString(undefined, {minimumFractionDigits: 2});

      // Update ticker
      const ticker = document.getElementById('ticker-container');
      ticker.innerHTML = currencies.map(c => \`
        <div class="inline-flex items-center gap-1">
          <span class="font-bold">\${c.code}</span>
          <span class="text-slate-400">§P \${parseFloat(c.valuePsd).toFixed(2)}</span>
        </div>
      \`).join('&nbsp;&nbsp;|&nbsp;&nbsp;');

      // Update balances
      const balList = document.getElementById('balances-list');
      let balHtml = \`<div class="flex justify-between py-1 border-b border-emerald-950">
        <span>PSD (Sovereign $)</span>
        <span class="font-bold text-amber-400 font-mono">§P \${balancePsd.toFixed(2)}</span>
      </div>\`;
      for (const [code, amt] of Object.entries(userBalances)) {
        if (amt > 0) {
          balHtml += \`<div class="flex justify-between py-1 border-b border-emerald-950">
            <span>\${code}</span>
            <span class="font-mono text-slate-200">\${parseFloat(amt).toFixed(2)}</span>
          </div>\`;
        }
      }
      balList.innerHTML = balHtml;

      // Update nations list
      const natList = document.getElementById('nations-list');
      natList.innerHTML = nations.map(n => \`
        <div class="bg-[#050907] border border-emerald-950 p-3 rounded-lg">
          <div class="flex justify-between font-bold text-slate-200">
            <span>\${n.name}</span>
            <span class="text-amber-400 font-mono">\${n.sovereignIndex}/100</span>
          </div>
          <p class="text-[11px] text-slate-400 mt-1 italic">\${n.description || 'Nessuna descrizione.'}</p>
        </div>
      \`).join('');

      // Update orders log
      const logs = document.getElementById('orders-log');
      logs.innerHTML = ordersLog.map(log => \`
        <div class="border-b border-emerald-950 py-1 flex justify-between">
          <span>\${log.type} \${log.amount} \${log.code}</span>
          <span class="text-amber-500">§P \${log.total.toFixed(2)}</span>
        </div>
      \`).join('');
    }

    function executeTrade() {
      const code = document.getElementById('trade-asset').value;
      const type = document.getElementById('trade-type').value;
      const amount = parseFloat(document.getElementById('trade-amount').value || '0');
      const feedback = document.getElementById('trade-feedback');

      if (isNaN(amount) || amount <= 0) {
        feedback.innerText = 'Inserire un importo valido.';
        feedback.className = 'mt-3 text-xs text-center text-red-400 font-bold';
        return;
      }

      const curr = currencies.find(c => c.code === code);
      const price = parseFloat(curr.valuePsd);
      const totalCost = amount * price;

      if (type === 'BUY') {
        if (balancePsd < totalCost) {
          feedback.innerText = 'Saldo PSD insufficiente.';
          feedback.className = 'mt-3 text-xs text-center text-red-400 font-bold';
          return;
        }
        balancePsd -= totalCost;
        userBalances[code] = (userBalances[code] || 0) + amount;
      } else {
        const owned = userBalances[code] || 0;
        if (owned < amount) {
          feedback.innerText = 'Saldo di ' + code + ' insufficiente.';
          feedback.className = 'mt-3 text-xs text-center text-red-400 font-bold';
          return;
        }
        balancePsd += totalCost;
        userBalances[code] = owned - amount;
      }

      // Add order log
      ordersLog.unshift({ type, code, amount, total: totalCost, date: new Date().toLocaleTimeString() });
      if (ordersLog.length > 20) ordersLog.pop();

      saveState();
      updateUi();

      feedback.innerText = 'Ordine eseguito con successo!';
      feedback.className = 'mt-3 text-xs text-center text-emerald-400 font-bold';
    }

    // Auto update prices
    setInterval(() => {
      currencies = currencies.map(c => {
        const change = (Math.random() - 0.5) * 0.04;
        const newVal = parseFloat(c.valuePsd) * (1 + change);
        return { ...c, valuePsd: newVal.toString() };
      });
      updateUi();
    }, 15000);

    // Initial setup
    updateUi();
  </script>
</body>
</html>`;

    const blob = new Blob([offlineTemplate], { type: 'text/html' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'sipse-sovereign-offline.html';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    addFeedEvent('Web App Standalone Offline scaricata con successo! Aprila sul tuo computer.');
  };


  // Copy WordPres shortcode utility
  const handleCopyShortcode = () => {
    let codeStr: string = selectedShortcode;
    if (selectedShortcode === '[piso_exchange]') {
      codeStr = `[piso_exchange theme="${scTheme}" limit="${scLimit}" show_chart="true"]`;
    } else if (selectedShortcode === '[pnrx_exchange]') {
      codeStr = `[pnrx_exchange theme="${scTheme}" limit="${scLimit}"]`;
    } else {
      codeStr = `[sipse_dashboard theme="${scTheme}" show_map="true"]`;
    }
    navigator.clipboard.writeText(codeStr);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  // Fetch and copy single-file standalone offline HTML Web App source text to clipboard
  const handleCopyMasterApp = async () => {
    try {
      const res = await fetch('/single-file-sipse.html');
      const text = await res.text();
      navigator.clipboard.writeText(text);
      setCopiedMasterApp(true);
      addFeedEvent('Codice sorgente Standalone copiato negli appunti! Incollalo in un file .html.');
      setTimeout(() => setCopiedMasterApp(false), 3000);
    } catch (err) {
      console.error('Copy Master App error:', err);
      alert('Impossibile copiare automaticamente. Scarica il file usando il pulsante dedicato.');
    }
  };

  // Helper variables for computations
  const pIsoCurrencies = state?.currencies.filter(c => c.category === 'P-ISO') || [];
  const pnrxAssets = state?.currencies.filter(c => c.category === 'PNRX') || [];
  const selectedAsset = state?.currencies.find(c => c.code === selectedAssetCode);
  const userPsdBalance = state?.balances.find(b => b.currencyCode === 'PSD')?.balance || '0.0000';
  const userSelectedAssetBalance = state?.balances.find(b => b.currencyCode === selectedAssetCode)?.balance || '0.0000';

  // Extract simulated price history for charting
  const selectedAssetHistory = state?.priceHistory
    ? [...state.priceHistory].filter(h => h.currencyCode === selectedAssetCode).reverse()
    : [];

  // SVG Chart path calculation helper
  const renderSvgChartPath = (history: PriceTick[], width: number, height: number) => {
    if (history.length < 2) {
      return {
        path: `M 0 ${height / 2} L ${width} ${height / 2}`,
        pointsObj: [],
        min: 0.1,
        max: 10
      };
    }
    const prices = history.map(h => parseFloat(h.price));
    const min = Math.min(...prices);
    const max = Math.max(...prices);
    const range = max - min === 0 ? 1 : max - min;

    const points = history.map((tick, i) => {
      const x = (i / (history.length - 1)) * width;
      const y = height - 12 - ((parseFloat(tick.price) - min) / range) * (height - 24);
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    });

    return {
      path: `M ${points.join(' L ')}`,
      pointsObj: points.map((p, i) => {
        const [x, y] = p.split(',');
        return { x: parseFloat(x), y: parseFloat(y), price: prices[i], date: new Date(history[i].timestamp).toLocaleTimeString() };
      }),
      min,
      max
    };
  };

  // Filter nations
  const filteredNations = state?.nations.filter(n => {
    const matchesSearch = n.name.toLowerCase().includes(nationSearch.toLowerCase()) ||
                          n.description.toLowerCase().includes(nationSearch.toLowerCase());
    const matchesRegion = nationRegionFilter === 'ALL' || n.region === nationRegionFilter;
    return matchesSearch && matchesRegion;
  }) || [];

  return (
    <div className="min-h-screen bg-[#070e0a] text-slate-100 font-sans antialiased selection:bg-amber-500 selection:text-black">
      
      {/* 1. CONTINUOUS HORIZONTAL TICKER */}
      <div className="bg-[#0b1610] border-b border-emerald-950 text-xs py-2 overflow-hidden shadow-md sticky top-0 z-40">
        <div className="max-w-[1400px] mx-auto px-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-amber-400 font-semibold shrink-0">
            <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>LIVE EXCHANGES §P:</span>
          </div>
          <div className="flex gap-6 overflow-x-auto no-scrollbar scroll-smooth py-1 px-2 select-none whitespace-nowrap text-slate-300 w-full mask-gradient">
            {state?.currencies.map((curr) => {
              const isPositive = parseFloat(curr.changePercent) >= 0;
              return (
                <div 
                  key={curr.code} 
                  onClick={() => setSelectedAssetCode(curr.code)}
                  className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded cursor-pointer hover:bg-emerald-950/50 transition-colors ${
                    selectedAssetCode === curr.code ? 'ring-1 ring-amber-400 bg-emerald-900/40' : ''
                  }`}
                >
                  <span className="font-bold text-slate-200">{curr.code}</span>
                  <span className="text-slate-400 font-mono">§P {parseFloat(curr.valuePsd).toFixed(2)}</span>
                  <span className={`inline-flex items-center text-[10px] font-mono font-bold ${isPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {isPositive ? <TrendingUp className="w-2.5 h-2.5 mr-0.5" /> : <TrendingDown className="w-2.5 h-2.5 mr-0.5" />}
                    {isPositive ? '+' : ''}{curr.changePercent}%
                  </span>
                </div>
              );
            })}
          </div>
          <div className="shrink-0 flex items-center gap-2 text-slate-400 text-[11px] bg-emerald-950/60 px-2.5 py-1 rounded border border-emerald-900">
            <RefreshCw className={`w-3 h-3 text-emerald-400 ${isSimulatingTick ? 'animate-spin' : ''}`} />
            <span>Formula Update: <b className="font-mono text-amber-400">{simCountdown}s</b></span>
          </div>
        </div>
      </div>

      {/* SIPSE-SOVEREIGN.ORG INTEGRATION BANNER */}
      <div className="bg-gradient-to-r from-amber-500/10 via-emerald-500/10 to-amber-500/10 border-b border-emerald-900/50 py-2">
        <div className="max-w-[1400px] mx-auto px-4 flex flex-col sm:flex-row items-center justify-center gap-2 text-center">
          <span className="text-[10px] uppercase tracking-widest text-amber-400 font-bold">Collegato a</span>
          <a 
            href="https://sipsesovereign.org/" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-xs font-mono text-emerald-400 hover:text-emerald-300 underline transition-colors flex items-center gap-1"
          >
            <Globe className="w-3 h-3" />
            sipsesovereign.org
          </a>
          <span className="text-[10px] text-slate-500 hidden sm:inline">|</span>
          <span className="text-[10px] text-slate-400">SIPSE Sovereign Financial Network v1.0 - Live Data Stream</span>
        </div>
      </div>

      {/* INSTITUTIONAL SITE HERO SECTION */}
      <section className="relative overflow-hidden bg-gradient-to-b from-[#0a150e] to-[#070e0a] border-b border-emerald-950/40 py-16 md:py-20">
        <div className="absolute top-0 right-1/4 w-[400px] h-[400px] bg-emerald-500/5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="max-w-[1400px] mx-auto px-4 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 bg-emerald-950/60 border border-emerald-900/80 px-3.5 py-1.5 rounded-full">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="text-[11px] font-mono text-emerald-300 font-bold tracking-wider">SIPSE Sovereign Financial Network (SSFN)</span>
            </div>

            <h1 className="text-4xl md:text-5xl font-black tracking-tight leading-[1.1] text-slate-100">
              Il Modello Finanziario Alternativo per i <span className="bg-gradient-to-r from-amber-400 to-emerald-400 bg-clip-text text-transparent">Popoli Sovrani</span>.
            </h1>
            
            <p className="text-slate-300 text-sm md:text-base leading-relaxed max-w-2xl">
              Ancorato a riserve biologiche verificate, foreste vergini, griglie solari locali e densità demografica. Benvenuto nell&apos;interfaccia di sviluppo per **sipsesovereign.org**, concepita per gestire, scambiare e programmare l&apos;indipendenza monetaria globale.
            </p>

            <div className="flex flex-wrap gap-3 pt-2">
              <a 
                href="https://sipsesovereign.org/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-emerald-500 hover:bg-emerald-400 text-black px-6 py-3 rounded-lg text-xs font-extrabold uppercase tracking-wider flex items-center gap-1.5 shadow-lg shadow-emerald-500/10 transition-all cursor-pointer"
              >
                Visita sipsesovereign.org
                <ChevronRight className="w-4 h-4" />
              </a>
              <button 
                onClick={() => {
                  const el = document.getElementById('main-suite');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className="bg-emerald-950/80 hover:bg-emerald-900 text-emerald-400 border border-emerald-800 px-6 py-3 rounded-lg text-xs font-extrabold uppercase tracking-wider transition-all cursor-pointer"
              >
                Esplora l&apos;App Live
              </button>
            </div>
          </div>

          <div className="lg:col-span-5 bg-[#0b140f]/60 border border-emerald-950 p-6 rounded-2xl shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-16 h-16 bg-amber-500/5 rounded-bl-full"></div>
            <h3 className="text-xs font-bold text-amber-400 uppercase tracking-widest border-b border-emerald-950/80 pb-3.5 mb-4 flex items-center justify-between">
              <span>STATO ACCREDITAMENTO</span>
              <span className="text-[10px] font-mono bg-emerald-950 text-emerald-400 px-2 py-0.5 rounded border border-emerald-900/60">Live Audited</span>
            </h3>

            <div className="space-y-4 text-xs">
              <div className="flex justify-between items-center bg-[#050907]/40 p-3 rounded border border-emerald-950">
                <span className="text-slate-400 flex items-center gap-2">
                  <Users className="w-4 h-4 text-emerald-400" /> Popolazione Totale
                </span>
                <span className="font-mono font-bold text-slate-100 text-sm">482,000,000</span>
              </div>

              <div className="flex justify-between items-center bg-[#050907]/40 p-3 rounded border border-emerald-950">
                <span className="text-slate-400 flex items-center gap-2">
                  <Globe className="w-4 h-4 text-emerald-400" /> Popoli Aderenti
                </span>
                <span className="font-mono font-bold text-slate-100 text-sm">{state?.metrics.totalNationsCount ?? 127}</span>
              </div>

              <div className="flex justify-between items-center bg-[#050907]/40 p-3 rounded border border-emerald-950">
                <span className="text-slate-400 flex items-center gap-2">
                  <Award className="w-4 h-4 text-amber-400" /> Indice Sovrano Medio
                </span>
                <span className="font-mono font-bold text-amber-400 text-sm">{state?.metrics.avgSovereignIndex ?? '83.60'}/100</span>
              </div>

              <div className="flex justify-between items-center bg-[#050907]/40 p-3 rounded border border-emerald-950">
                <span className="text-slate-400 flex items-center gap-2">
                  <Database className="w-4 h-4 text-emerald-400" /> Valore Base
                </span>
                <span className="font-mono font-bold text-slate-100 text-sm">1.00 PSD (§P)</span>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* 2. CORE SUPERSTRUCTURE NAVIGATION & HERO */}
      <header className="relative overflow-hidden border-b border-emerald-950/70 bg-gradient-to-b from-[#0b1610] to-[#070e0a] pt-8 pb-6" id="main-suite">
        <div className="max-w-[1400px] mx-auto px-4">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div>
              <h2 className="text-2xl lg:text-3xl font-extrabold tracking-tight bg-gradient-to-r from-white via-slate-100 to-amber-200 bg-clip-text text-transparent">
                Pannello di Controllo Finanziario
              </h2>
              <p className="mt-1.5 text-slate-400 text-xs max-w-2xl leading-relaxed">
                Interagisci con l&apos;ecosistema. Le azioni effettuate modificano i valori in tempo reale sul database PostgreSQL.
              </p>
            </div>

            {/* Quick action system console triggers */}
            <div className="flex flex-wrap items-center gap-2.5 lg:self-end">
              <button 
                onClick={downloadOfflineApp} 
                className="bg-amber-400 hover:bg-amber-500 text-black px-4 py-2 rounded-lg text-xs font-extrabold flex items-center gap-2 transition-all cursor-pointer shadow-lg shadow-amber-900/20"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                Scarica Web App Offline (.html)
              </button>
              <button 
                onClick={() => fetchState()} 
                className="bg-emerald-950/80 hover:bg-emerald-900 text-emerald-400 border border-emerald-800/80 hover:border-emerald-700 px-4 py-2 rounded-lg text-xs font-medium flex items-center gap-2 transition-all cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Aggiorna Dati
              </button>
              <button 
                onClick={handleResetSystem}
                className="bg-rose-950/40 hover:bg-rose-900/30 text-rose-400 border border-rose-900/50 hover:border-rose-800 px-4 py-2 rounded-lg text-xs font-medium flex items-center gap-2 transition-all cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Resetta Database
              </button>
            </div>
          </div>

          {/* MAIN TABS SELECTOR */}
          <div className="mt-8 border-b border-emerald-950/70 flex flex-wrap gap-1.5">
            <button
              onClick={() => setActiveTab('exchange')}
              className={`px-4 py-3 text-xs font-bold tracking-wider uppercase rounded-t-lg flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === 'exchange'
                  ? 'bg-emerald-950/60 text-amber-400 border-t-2 border-l border-r border-emerald-900 border-t-amber-400'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-emerald-950/10'
              }`}
            >
              <ArrowLeftRight className="w-4 h-4" />
              Mercato & Exchange (PSX / PNRX)
            </button>
            <button
              onClick={() => setActiveTab('governance')}
              className={`px-4 py-3 text-xs font-bold tracking-wider uppercase rounded-t-lg flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === 'governance'
                  ? 'bg-emerald-950/60 text-amber-400 border-t-2 border-l border-r border-emerald-900 border-t-amber-400'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-emerald-950/10'
              }`}
            >
              <Sliders className="w-4 h-4 text-emerald-500" />
              SIPSE Governance AI Engine
            </button>
            <button
              onClick={() => setActiveTab('registry')}
              className={`px-4 py-3 text-xs font-bold tracking-wider uppercase rounded-t-lg flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === 'registry'
                  ? 'bg-emerald-950/60 text-amber-400 border-t-2 border-l border-r border-emerald-900 border-t-amber-400'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-emerald-950/10'
              }`}
            >
              <Globe className="w-4 h-4" />
              Registro Demografico SPR
            </button>
            <button
              onClick={() => setActiveTab('authority')}
              className={`px-4 py-3 text-xs font-bold tracking-wider uppercase rounded-t-lg flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === 'authority'
                  ? 'bg-emerald-950/60 text-amber-400 border-t-2 border-l border-r border-emerald-900 border-t-amber-400'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-emerald-950/10'
              }`}
            >
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              Autorità Monetaria PICA & Riserve
            </button>
            <button
              onClick={() => setActiveTab('shortcodes')}
              className={`px-4 py-3 text-xs font-bold tracking-wider uppercase rounded-t-lg flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === 'shortcodes'
                  ? 'bg-emerald-950/60 text-amber-400 border-t-2 border-l border-r border-emerald-900 border-t-amber-400'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-emerald-950/10'
              }`}
            >
              <Code className="w-4 h-4 text-blue-400" />
              Integrazione WordPress
            </button>
            <button
              onClick={() => setActiveTab('api')}
              className={`px-4 py-3 text-xs font-bold tracking-wider uppercase rounded-t-lg flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === 'api'
                  ? 'bg-emerald-950/60 text-amber-400 border-t-2 border-l border-r border-emerald-900 border-t-amber-400'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-emerald-950/10'
              }`}
            >
              <FileCode className="w-4 h-4 text-teal-400" />
              REST API Explorer
            </button>
          </div>

        </div>
      </header>

      {/* 4. MAIN LAYOUT AND TAB CONTENT */}
      <main className="max-w-[1400px] mx-auto px-4 py-8">
        {error && (
          <div className="mb-6 p-4 bg-rose-950/50 border border-rose-800 text-rose-300 rounded-xl text-sm flex items-start gap-3">
            <span className="bg-rose-900 text-rose-100 font-bold px-2 py-0.5 rounded text-xs">Error</span>
            <div>
              <p className="font-semibold">Si è verificato un errore di sincronizzazione con il database:</p>
              <p className="mt-1 text-xs font-mono">{error}</p>
              <button 
                onClick={() => fetchState()} 
                className="mt-2 text-xs text-amber-400 underline hover:text-amber-300 font-semibold flex items-center gap-1 cursor-pointer"
              >
                Riprova a stabilire la connessione
              </button>
            </div>
          </div>
        )}

        {loading ? (
          <div className="py-24 text-center">
            <div className="inline-block w-10 h-10 border-4 border-amber-400/30 border-t-amber-400 rounded-full animate-spin"></div>
            <p className="mt-4 text-sm text-slate-400 font-mono">Interrogazione database PostgreSQL in corso...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            
            {/* CENTRAL SIDEBAR FOR LIVE NOTIFICATIONS AND STATS */}
            <div className="lg:col-span-1 flex flex-col gap-6">
              
              {/* WALLET INTERACTIVE CARD */}
              <div className="bg-[#0b1410] border border-emerald-950 rounded-xl p-5 shadow-lg">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center justify-between">
                  <span>LIVE DIGITAL WALLET</span>
                  <span className="text-[10px] text-emerald-400 font-mono px-2 py-0.5 rounded bg-emerald-950/80">Active</span>
                </h3>
                
                <div className="bg-emerald-950/30 border border-emerald-900/60 rounded-lg p-3.5 mb-4">
                  <p className="text-[10px] text-slate-400 uppercase tracking-widest font-mono">Sovereign Wallet Address</p>
                  <p className="text-xs font-mono text-slate-200 mt-1 select-all break-all bg-emerald-950/40 p-1.5 rounded border border-emerald-900/40">{userWalletAddress}</p>
                </div>

                <div className="space-y-3">
                  <p className="text-xs font-bold text-slate-300 flex justify-between">
                    <span>Valuta</span>
                    <span>Bilancio Personale</span>
                  </p>
                  
                  {/* Default Sovereign Dollar balance */}
                  <div className="flex justify-between items-center text-xs border-b border-emerald-950/60 pb-2">
                    <span className="font-bold text-slate-200 flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
                      PSD (§P Sovereign $)
                    </span>
                    <span className="font-mono font-bold text-amber-400">{parseFloat(userPsdBalance).toFixed(4)}</span>
                  </div>

                  {/* Render other token balances if populated */}
                  {state?.balances.filter(b => b.currencyCode !== 'PSD').map(b => (
                    <div key={b.currencyCode} className="flex justify-between items-center text-xs border-b border-emerald-950/60 pb-2">
                      <span className="font-bold text-slate-300 flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
                        {b.currencyCode}
                      </span>
                      <span className="font-mono text-slate-200">{parseFloat(b.balance).toFixed(4)}</span>
                    </div>
                  ))}
                  
                  {state?.balances.filter(b => b.currencyCode !== 'PSD').length === 0 && (
                    <p className="text-[11px] text-slate-500 italic text-center py-2">Nessun altro asset detenuto. Esegui un ordine per acquistare valute o beni.</p>
                  )}
                </div>

                <div className="mt-4 pt-3 border-t border-emerald-900/40 text-center">
                  <p className="text-[10px] text-slate-400">Le transazioni modificano il prezzo degli asset in base alla liquidità dell&apos;ecosistema.</p>
                </div>
              </div>

              {/* LIVE NOTIFICATIONS EVENT STREAM */}
              <div className="bg-[#0b1410] border border-emerald-950 rounded-xl p-5 shadow-lg flex-1">
                <div className="flex items-center justify-between mb-4 pb-2 border-b border-emerald-950/80">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
                    <Activity className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                    Feed Log SSFN v1.0
                  </h3>
                  <span className="text-[10px] text-slate-500 font-mono">Live</span>
                </div>

                <div className="space-y-3.5 max-h-[350px] overflow-y-auto pr-1 no-scrollbar text-xs">
                  {feedEvents.map((evt, idx) => (
                    <div key={idx} className="border-l-2 border-emerald-800 pl-3 py-0.5">
                      <p className="text-slate-300 leading-relaxed text-[11px]">{evt}</p>
                      <span className="text-[9px] text-slate-500 font-mono">Simulated System event</span>
                    </div>
                  ))}
                </div>
              </div>

            </div>

            {/* TAB CONTENT SPANNING 3 COLUMNS */}
            <div className="lg:col-span-3">
              
              {/* TAB 1: EXCHANGE & TRADING MARKET */}
              {activeTab === 'exchange' && (
                <div className="space-y-6">
                  
                  {/* ALTERNATIVE SHARING SYSTEM (BULLETPROOF) */}
                  <div className="bg-gradient-to-r from-amber-500/10 via-[#0b1410] to-amber-950/20 border border-amber-500/30 p-5 rounded-xl shadow-lg relative overflow-hidden">
                    <div className="absolute top-0 right-0 bg-amber-500/20 text-amber-300 text-[9px] uppercase tracking-widest px-2.5 py-1 rounded-bl">
                      Sistema Alternativo Consigliato
                    </div>
                    <h3 className="text-sm font-extrabold text-amber-400 flex items-center gap-2">
                      <PlusCircle className="w-5 h-5 text-amber-400" />
                      Vuoi inviare l&apos;applicazione a un amico? (Condivisione 100% Garantita)
                    </h3>
                    <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                      Se il link temporaneo della sandbox richiede login o mostra schermate vuote, usa questo metodo infallibile. Puoi fargli scaricare l&apos;applicazione interattiva completa come file unico che funziona totalmente offline!
                    </p>
                    <div className="mt-4 flex flex-wrap gap-2.5">
                      <a 
                        href="/single-file-sipse.html" 
                        download="sipse-sovereign-app.html"
                        className="bg-emerald-500 hover:bg-emerald-400 text-black px-4 py-2 rounded font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow"
                      >
                        <Download className="w-4 h-4" />
                        Scarica l&apos;App Standalone (.html)
                      </a>
                      <button 
                        onClick={handleCopyMasterApp}
                        className="bg-emerald-950 hover:bg-emerald-900 text-emerald-400 border border-emerald-800 px-4 py-2 rounded font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                      >
                        {copiedMasterApp ? (
                          <>
                            <Check className="w-4 h-4 text-emerald-400" />
                            Codice Copiato!
                          </>
                        ) : (
                          <>
                            <Copy className="w-4 h-4" />
                            Copia Codice Master per il tuo amico
                          </>
                        )}
                      </button>
                    </div>
                    <p className="text-[10px] text-slate-500 mt-3 font-mono leading-tight">
                      * Istruzioni per l&apos;amico: Incolla il codice in un file di testo, salvalo come <span className="text-amber-400">sipse.html</span> e fai doppio clic per avviarlo! Salverà i dati nel browser in modo permanente.
                    </p>
                  </div>

                  {/* WELCOME BANNER & DESCRIPTION */}
                  <div className="bg-gradient-to-r from-emerald-950/50 via-[#0b1410] to-emerald-950/30 border border-emerald-950 p-5 rounded-xl">
                    <h2 className="text-lg font-bold text-amber-400 flex items-center gap-2">
                      <Coins className="w-5 h-5" />
                      Mercato di Scambio Sovrano: PSX & PNRX
                    </h2>
                    <p className="text-slate-300 text-xs mt-1.5 leading-relaxed">
                      Seleziona un asset per visualizzare l&apos;andamento storico simulato, leggere i dati di copertura di base ed eseguire operazioni di acquisto e vendita dirette. 
                      I prezzi si aggiornano automaticamente ogni <b>15 secondi</b> secondo l&apos;algoritmo ufficiale SIPSE o in risposta alle tue compravendite.
                    </p>
                  </div>

                  {/* ASSETS SELECTION GRID */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    
                    {/* CURRENCIES P-ISO (PSX) */}
                    <div className="bg-[#0b1410] border border-emerald-950 rounded-xl p-4 shadow-md">
                      <h3 className="text-xs font-bold text-amber-400 uppercase tracking-widest border-b border-emerald-950 pb-2 mb-3 flex justify-between items-center">
                        <span>1. Valute Ufficiali P-ISO (PSX)</span>
                        <span className="text-[10px] text-slate-400 font-mono">Copertura in Servizi & Produzione</span>
                      </h3>
                      
                      <div className="space-y-1.5 max-h-[400px] overflow-y-auto pr-1">
                        {pIsoCurrencies.map((curr) => {
                          const isSelected = curr.code === selectedAssetCode;
                          const isPositive = parseFloat(curr.changePercent) >= 0;
                          return (
                            <div
                              key={curr.code}
                              onClick={() => {
                                setSelectedAssetCode(curr.code);
                                setTradeStatus({ type: null, message: '' });
                              }}
                              className={`flex items-center justify-between p-2.5 rounded-lg transition-all cursor-pointer ${
                                isSelected 
                                  ? 'bg-emerald-900/40 border border-amber-400/40 shadow-inner' 
                                  : 'hover:bg-emerald-950/40 border border-transparent'
                              }`}
                            >
                              <div className="flex items-center gap-2.5">
                                <span className="bg-emerald-950 text-slate-200 font-mono font-bold text-xs w-9 h-9 rounded-lg flex items-center justify-center border border-emerald-900">
                                  {curr.code}
                                </span>
                                <div>
                                  <p className="text-xs font-bold text-slate-200">{curr.name}</p>
                                  <p className="text-[10px] text-slate-400 truncate max-w-[150px]">{curr.baseAsset}</p>
                                </div>
                              </div>

                              <div className="text-right">
                                <p className="text-xs font-bold font-mono text-slate-200">§P {parseFloat(curr.valuePsd).toFixed(4)}</p>
                                <span className={`inline-flex items-center text-[10px] font-mono font-bold ${isPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
                                  {isPositive ? '+' : ''}{curr.changePercent}%
                                </span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* NATURAL RESOURCES EXCHANGE (PNRX) */}
                    <div className="bg-[#0b1410] border border-emerald-950 rounded-xl p-4 shadow-md">
                      <h3 className="text-xs font-bold text-amber-400 uppercase tracking-widest border-b border-emerald-950 pb-2 mb-3 flex justify-between items-center">
                        <span>2. People&apos;s Natural Resources (PNRX)</span>
                        <span className="text-[10px] text-slate-400 font-mono">Ancoraggio a Materie Prime Reali</span>
                      </h3>

                      <div className="space-y-1.5 max-h-[400px] overflow-y-auto pr-1">
                        {pnrxAssets.map((curr) => {
                          const isSelected = curr.code === selectedAssetCode;
                          const isPositive = parseFloat(curr.changePercent) >= 0;
                          return (
                            <div
                              key={curr.code}
                              onClick={() => {
                                setSelectedAssetCode(curr.code);
                                setTradeStatus({ type: null, message: '' });
                              }}
                              className={`flex items-center justify-between p-2.5 rounded-lg transition-all cursor-pointer ${
                                isSelected 
                                  ? 'bg-emerald-900/40 border border-amber-400/40 shadow-inner' 
                                  : 'hover:bg-emerald-950/40 border border-transparent'
                              }`}
                            >
                              <div className="flex items-center gap-2.5">
                                <span className="bg-amber-950/30 text-amber-300 font-mono font-bold text-xs w-9 h-9 rounded-lg flex items-center justify-center border border-amber-900/40">
                                  {curr.code}
                                </span>
                                <div>
                                  <p className="text-xs font-bold text-slate-200">{curr.name}</p>
                                  <p className="text-[10px] text-slate-400 truncate max-w-[150px]">{curr.baseAsset}</p>
                                </div>
                              </div>

                              <div className="text-right">
                                <p className="text-xs font-bold font-mono text-slate-200">§P {parseFloat(curr.valuePsd).toFixed(2)}</p>
                                <span className={`inline-flex items-center text-[10px] font-mono font-bold ${isPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
                                  {isPositive ? '+' : ''}{curr.changePercent}%
                                </span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                  </div>

                  {/* SELECTED ASSET CHART AND ORDER BOX */}
                  {selectedAsset && (
                    <div className="bg-[#0b1410] border border-emerald-950 rounded-xl p-6 shadow-lg">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-emerald-950/80 mb-6">
                        <div className="flex items-center gap-3">
                          <span className="bg-gradient-to-br from-amber-400 to-emerald-400 text-black font-extrabold font-mono text-sm px-3.5 py-1.5 rounded-xl">
                            {selectedAsset.code}
                          </span>
                          <div>
                            <h3 className="text-base font-bold text-slate-100">{selectedAsset.name}</h3>
                            <p className="text-xs text-slate-400">
                              Ecosistema di riferimento: <span className="text-emerald-400 font-semibold">{selectedAsset.baseAsset}</span>
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-6">
                          <div>
                            <p className="text-[10px] text-slate-400 uppercase tracking-widest text-right">Prezzo Corrente</p>
                            <p className="text-xl font-mono font-bold text-amber-400 text-right">
                              §P {parseFloat(selectedAsset.valuePsd).toFixed(4)}
                            </p>
                          </div>
                          <div>
                            <p className="text-[10px] text-slate-400 uppercase tracking-widest text-right">Variazione</p>
                            <p className={`text-sm font-mono font-bold text-right ${parseFloat(selectedAsset.changePercent) >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                              {parseFloat(selectedAsset.changePercent) >= 0 ? '+' : ''}{selectedAsset.changePercent}%
                            </p>
                          </div>
                          {selectedAsset.capPsd && (
                            <div>
                              <p className="text-[10px] text-slate-400 uppercase tracking-widest text-right">Cap Emissione</p>
                              <p className="text-sm font-mono font-bold text-slate-200 text-right">
                                {(selectedAsset.capPsd / 1e9).toFixed(1)}B §P
                              </p>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* CHART AND ORDER FORM DOUBLE GRID */}
                      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        
                        {/* CHART COLUMN */}
                        <div className="lg:col-span-2 space-y-4">
                          <div className="flex items-center justify-between">
                            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                              <i className="w-3.5 h-3.5 text-emerald-400"><Activity className="w-full h-full" /></i>
                              Andamento Storico Recente
                            </h4>
                            <span className="text-[10px] text-slate-400 font-mono">Ancoraggio e Variazione Liquida</span>
                          </div>

                          <div className="bg-[#050907] border border-emerald-950/80 rounded-lg p-3 relative h-52 flex flex-col justify-between">
                            
                            {/* SVG Chart */}
                            {selectedAssetHistory.length > 1 ? (() => {
                              const width = 500;
                              const height = 150;
                              const chartData = renderSvgChartPath(selectedAssetHistory, width, height);
                              
                              return (
                                <div className="relative w-full h-full flex flex-col justify-between">
                                  <div className="absolute top-0 right-0 text-[10px] font-mono text-emerald-500/80 bg-emerald-950/40 px-2 py-0.5 rounded">
                                    Max: §P {chartData.max.toFixed(3)}
                                  </div>
                                  <div className="absolute bottom-0 right-0 text-[10px] font-mono text-rose-500/80 bg-rose-950/40 px-2 py-0.5 rounded">
                                    Min: §P {chartData.min.toFixed(3)}
                                  </div>

                                  {/* Custom beautiful gridlines */}
                                  <svg className="absolute inset-0 w-full h-full" preserveAspectRatio="none">
                                    <line x1="0" y1="37" x2="100%" y2="37" stroke="#0e2316" strokeDasharray="3,3" />
                                    <line x1="0" y1="75" x2="100%" y2="75" stroke="#0e2316" strokeDasharray="3,3" />
                                    <line x1="0" y1="112" x2="100%" y2="112" stroke="#0e2316" strokeDasharray="3,3" />
                                  </svg>

                                  <svg className="w-full h-[150px] overflow-visible" viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none">
                                    <defs>
                                      <linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="0%" stopColor="#10b981" stopOpacity="0.3" />
                                        <stop offset="100%" stopColor="#10b981" stopOpacity="0.0" />
                                      </linearGradient>
                                    </defs>
                                    <path
                                      d={`${chartData.path} L ${width} ${height} L 0 ${height} Z`}
                                      fill="url(#chartGradient)"
                                    />
                                    <path
                                      d={chartData.path}
                                      fill="none"
                                      stroke={parseFloat(selectedAsset.changePercent) >= 0 ? '#34d399' : '#f87171'}
                                      strokeWidth="2.5"
                                      strokeLinecap="round"
                                      strokeLinejoin="round"
                                    />
                                  </svg>

                                  {/* Bottom timeline simulation */}
                                  <div className="flex justify-between text-[9px] font-mono text-slate-500 mt-2">
                                    <span>Inizio Sessione</span>
                                    <span>{new Date().toLocaleTimeString()} (Live)</span>
                                  </div>
                                </div>
                              );
                            })() : (
                              <div className="h-full flex items-center justify-center">
                                <p className="text-xs text-slate-500">In attesa dell&apos;accumulo dei primi dati di mercato...</p>
                              </div>
                            )}

                          </div>
                          
                          <div className="p-3 bg-emerald-950/20 border border-emerald-950 rounded-lg">
                            <p className="text-[11px] text-slate-400 leading-relaxed">
                              <b>Analisi AI Sovereign Guard:</b> L&apos;asset <b className="text-slate-200">{selectedAsset.code}</b> mostra un indice di stabilità robusto. La domanda liquida simula l&apos;interscambio tra i 127 popoli. Ancoraggio biologico certificato al 100%.
                            </p>
                          </div>
                        </div>

                        {/* ORDER EXECUTION BOX COLUMN */}
                        <div className="bg-[#0e1b14] border border-emerald-900/60 rounded-xl p-4 flex flex-col justify-between">
                          <div>
                            <div className="flex items-center justify-between pb-3 border-b border-emerald-900/40 mb-4">
                              <h4 className="text-xs font-bold text-amber-400 uppercase tracking-widest">
                                Esegui Ordine Diretto
                              </h4>
                              <span className="text-[9px] text-slate-400 font-mono">Commissioni: 0.0%</span>
                            </div>

                            {/* Trade direction switch */}
                            <div className="grid grid-cols-2 gap-2 mb-4 bg-emerald-950/60 p-1 rounded-lg">
                              <button
                                type="button"
                                onClick={() => {
                                  setTradeType('BUY');
                                  setTradeStatus({ type: null, message: '' });
                                }}
                                className={`py-1.5 text-xs font-bold rounded-md transition-all cursor-pointer ${
                                  tradeType === 'BUY'
                                    ? 'bg-emerald-500 text-black shadow'
                                    : 'text-slate-300 hover:text-white'
                                }`}
                              >
                                Acquista ({selectedAsset.code})
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  setTradeType('SELL');
                                  setTradeStatus({ type: null, message: '' });
                                }}
                                className={`py-1.5 text-xs font-bold rounded-md transition-all cursor-pointer ${
                                  tradeType === 'SELL'
                                    ? 'bg-rose-500 text-white shadow'
                                    : 'text-slate-300 hover:text-white'
                                }`}
                              >
                                Vendi ({selectedAsset.code})
                              </button>
                            </div>

                            <form onSubmit={handleExecuteTrade} className="space-y-4">
                              <div>
                                <label className="block text-[10px] uppercase text-slate-400 font-bold mb-1.5">
                                  Quantità da scambiare
                                </label>
                                <div className="relative">
                                  <input
                                    type="number"
                                    step="any"
                                    min="0.0001"
                                    value={tradeAmount}
                                    onChange={(e) => setTradeAmount(e.target.value)}
                                    className="w-full bg-[#050907] border border-emerald-900 rounded-lg px-3 py-2 text-sm font-mono text-slate-100 focus:outline-none focus:ring-1 focus:ring-amber-400"
                                    placeholder="0.00"
                                    required
                                  />
                                  <span className="absolute right-3 top-2.5 text-xs font-mono font-bold text-slate-400">
                                    {selectedAsset.code}
                                  </span>
                                </div>
                              </div>

                              <div className="bg-[#050907] p-3 rounded-lg space-y-2 text-xs font-mono border border-emerald-950">
                                <div className="flex justify-between text-slate-400">
                                  <span>Prezzo unitario:</span>
                                  <span className="text-slate-200">§P {parseFloat(selectedAsset.valuePsd).toFixed(4)}</span>
                                </div>
                                <div className="flex justify-between text-slate-400">
                                  <span>Il Tuo Saldo {selectedAsset.code}:</span>
                                  <span className="text-slate-200">{parseFloat(userSelectedAssetBalance).toFixed(4)}</span>
                                </div>
                                <div className="flex justify-between text-slate-400">
                                  <span>Il Tuo Saldo PSD:</span>
                                  <span className="text-slate-200">§P {parseFloat(userPsdBalance).toFixed(4)}</span>
                                </div>
                                <hr className="border-emerald-950" />
                                <div className="flex justify-between text-slate-200 font-bold">
                                  <span>Totale Stimat:</span>
                                  <span className="text-amber-400">
                                    §P {(parseFloat(tradeAmount || '0') * parseFloat(selectedAsset.valuePsd)).toFixed(4)}
                                  </span>
                                </div>
                              </div>

                              <button
                                type="submit"
                                className={`w-full py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
                                  tradeType === 'BUY'
                                    ? 'bg-amber-400 hover:bg-amber-500 text-black shadow-lg shadow-amber-900/20'
                                    : 'bg-rose-600 hover:bg-rose-700 text-white shadow-lg shadow-rose-900/20'
                                }`}
                              >
                                {tradeType === 'BUY' ? 'Conferma Acquisto' : 'Conferma Vendita'}
                              </button>
                            </form>
                          </div>

                          {tradeStatus.type && (
                            <div className={`mt-4 p-3 rounded-lg text-xs border ${
                              tradeStatus.type === 'success' 
                                ? 'bg-emerald-950/40 border-emerald-800 text-emerald-300' 
                                : 'bg-rose-950/40 border-rose-900 text-rose-300'
                            }`}>
                              <p className="font-semibold">{tradeStatus.type === 'success' ? 'Eseguito!' : 'Negato'}</p>
                              <p className="mt-0.5 text-[11px]">{tradeStatus.message}</p>
                            </div>
                          )}

                        </div>

                      </div>

                    </div>
                  )}

                  {/* RECENT NETWORK ORDERS */}
                  <div className="bg-[#0b1410] border border-emerald-950 rounded-xl p-5 shadow-lg">
                    <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-emerald-950 pb-3 mb-4 flex justify-between items-center">
                      <span>Registro Ordini Recenti (SSFN Blockchain Layer)</span>
                      <span className="text-[10px] text-emerald-400 font-mono">Consenso Distribuito</span>
                    </h3>

                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs text-slate-300">
                        <thead>
                          <tr className="border-b border-emerald-950 text-slate-400 font-mono text-[10px] uppercase">
                            <th className="py-2">Data/Ora</th>
                            <th className="py-2">Mittente Wallet</th>
                            <th className="py-2">Tipo</th>
                            <th className="py-2">Asset</th>
                            <th className="py-2 text-right">Quantità</th>
                            <th className="py-2 text-right">Prezzo Unitario</th>
                            <th className="py-2 text-right">Totale PSD</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-emerald-950/40">
                          {state?.orders && state.orders.length > 0 ? (
                            state.orders.map((ord) => (
                              <tr key={ord.id} className="hover:bg-emerald-950/10 transition-colors">
                                <td className="py-2.5 font-mono text-[11px] text-slate-500">
                                  {new Date(ord.createdAt).toLocaleTimeString()}
                                </td>
                                <td className="py-2.5 font-mono text-slate-400 text-[11px]">
                                  {ord.walletAddress.substring(0, 16)}...
                                </td>
                                <td className="py-2.5">
                                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold ${
                                    ord.type === 'BUY' || ord.type === 'MINT'
                                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-900/60'
                                      : 'bg-rose-950 text-rose-400 border border-rose-900/60'
                                  }`}>
                                    {ord.type}
                                  </span>
                                </td>
                                <td className="py-2.5 font-bold text-slate-200">
                                  {ord.currencyCode}
                                </td>
                                <td className="py-2.5 text-right font-mono font-semibold text-slate-100">
                                  {parseFloat(ord.amount).toLocaleString(undefined, { minimumFractionDigits: 4 })}
                                </td>
                                <td className="py-2.5 text-right font-mono text-slate-300">
                                  §P {parseFloat(ord.pricePsd).toFixed(4)}
                                </td>
                                <td className="py-2.5 text-right font-mono font-bold text-amber-400">
                                  §P {parseFloat(ord.totalPsd).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                                </td>
                              </tr>
                            ))
                          ) : (
                            <tr>
                              <td colSpan={7} className="py-6 text-center text-slate-500 italic">
                                Nessun ordine registrato nella sessione corrente. Esegui la prima transazione per popolare il registro sovrano.
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>

                </div>
              )}

              {/* TAB 2: SIPSE GOVERNANCE AI ENGINE */}
              {activeTab === 'governance' && (
                <div className="space-y-6">
                  
                  {/* ALGORITHM FLOWCHART & EQUATION */}
                  <div className="bg-[#0b1410] border border-emerald-950 rounded-xl p-6 shadow-lg">
                    <h2 className="text-base font-bold text-amber-400 flex items-center gap-2 mb-3">
                      <Cpu className="w-5 h-5 text-emerald-400 animate-pulse" />
                      SIPSE Sovereign Algorithmic Formula
                    </h2>
                    
                    <p className="text-slate-300 text-xs leading-relaxed">
                      L&apos;emissione e la valorizzazione del <b className="text-slate-100">P-ISO Sovereign Dollar (§P)</b> e dei suoi asset collegati è dettata da un algoritmo trasparente multi-parametrale. Questo sistema previene manipolazioni esterne speculatrici e garantisce un valore intrinseco reale.
                    </p>

                    {/* Formula Highlight box */}
                    <div className="bg-[#050907] border border-emerald-900 rounded-xl p-5 my-6 text-center relative overflow-hidden">
                      <span className="absolute top-2 left-3 text-[10px] uppercase font-mono text-slate-500">Official Equation</span>
                      
                      <div className="inline-block bg-emerald-950/40 px-6 py-4 rounded-xl border border-emerald-900/60 shadow-inner">
                        <p className="text-xs text-slate-400 uppercase tracking-widest font-mono">Valore P-ISO Corrente</p>
                        <p className="text-lg md:text-2xl font-black text-amber-400 mt-2 font-mono">
                          §P = <span className="text-slate-100">(Risorse × Produzione × Domanda × Stabilità × Popolazione)</span>
                          <span className="block border-t border-slate-600 my-1 max-w-[400px] mx-auto"></span>
                          <span className="text-slate-400 text-base">Massa Monetaria in Circolazione</span>
                        </p>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mt-4 text-[11px] font-mono text-slate-400">
                        <div className="bg-[#0a120e] p-2 rounded">
                          <span className="text-emerald-400 block font-bold">Risorse</span>
                          Ancoraggio naturale
                        </div>
                        <div className="bg-[#0a120e] p-2 rounded">
                          <span className="text-emerald-400 block font-bold">Produzione</span>
                          Capacità di output
                        </div>
                        <div className="bg-[#0a120e] p-2 rounded">
                          <span className="text-emerald-400 block font-bold">Domanda</span>
                          Pressione acquisto
                        </div>
                        <div className="bg-[#0a120e] p-2 rounded">
                          <span className="text-emerald-400 block font-bold">Stabilità</span>
                          Indice ecologico
                        </div>
                        <div className="bg-[#0a120e] p-2 rounded col-span-2 md:col-span-1">
                          <span className="text-emerald-400 block font-bold">Popolazione</span>
                          SPR Registry
                        </div>
                      </div>
                    </div>

                    {/* INTERACTIVE COEFFICIENTS SLIDERS */}
                    <div className="bg-[#0e1b14] border border-emerald-900/50 rounded-lg p-5">
                      <h3 className="text-xs font-bold uppercase tracking-widest text-slate-300 mb-4 flex items-center justify-between">
                        <span>Simulatore Parametri AI Engine (Modificatori di Peso)</span>
                        <span className="text-emerald-400 font-mono text-[11px]">Machine learning: attivo</span>
                      </h3>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-4">
                          <div>
                            <div className="flex justify-between text-xs mb-1.5">
                              <span className="text-slate-300">Coefficiente Riserve Biologiche (Risorse)</span>
                              <span className="font-mono text-amber-400 font-bold">{sliderResources.toFixed(2)}x</span>
                            </div>
                            <input
                              type="range"
                              min="0.5"
                              max="2.0"
                              step="0.05"
                              value={sliderResources}
                              onChange={(e) => setSliderResources(parseFloat(e.target.value))}
                              className="w-full accent-emerald-500 h-1 bg-emerald-950 rounded-lg"
                            />
                            <p className="text-[10px] text-slate-500 mt-1">Impatto sul valore delle foreste, biodiversità e acqua dolce.</p>
                          </div>

                          <div>
                            <div className="flex justify-between text-xs mb-1.5">
                              <span className="text-slate-300">Capacità Produttiva Nominale (Produzione)</span>
                              <span className="font-mono text-amber-400 font-bold">{sliderProduction.toFixed(2)}x</span>
                            </div>
                            <input
                              type="range"
                              min="0.5"
                              max="2.0"
                              step="0.05"
                              value={sliderProduction}
                              onChange={(e) => setSliderProduction(parseFloat(e.target.value))}
                              className="w-full accent-emerald-500 h-1 bg-emerald-950 rounded-lg"
                            />
                            <p className="text-[10px] text-slate-500 mt-1">Impatto su energia solare, agroalimentare e innovazione tecnologica.</p>
                          </div>
                        </div>

                        <div className="space-y-4">
                          <div>
                            <div className="flex justify-between text-xs mb-1.5">
                              <span className="text-slate-300">Interscambio Popoli Aderenti (Domanda)</span>
                              <span className="font-mono text-amber-400 font-bold">{sliderDemand.toFixed(2)}x</span>
                            </div>
                            <input
                              type="range"
                              min="0.5"
                              max="2.0"
                              step="0.05"
                              value={sliderDemand}
                              onChange={(e) => setSliderDemand(parseFloat(e.target.value))}
                              className="w-full accent-emerald-500 h-1 bg-emerald-950 rounded-lg"
                            />
                            <p className="text-[10px] text-slate-500 mt-1">Impatto sui volumi globali stimati nel network.</p>
                          </div>

                          <div>
                            <div className="flex justify-between text-xs mb-1.5">
                              <span className="text-slate-300">Resilienza Bioclimatica (Stabilità)</span>
                              <span className="font-mono text-amber-400 font-bold">{sliderStability.toFixed(2)}x</span>
                            </div>
                            <input
                              type="range"
                              min="0.5"
                              max="2.0"
                              step="0.05"
                              value={sliderStability}
                              onChange={(e) => setSliderStability(parseFloat(e.target.value))}
                              className="w-full accent-emerald-500 h-1 bg-emerald-950 rounded-lg"
                            />
                            <p className="text-[10px] text-slate-500 mt-1">Previene l&apos;inflazione e la volatilità dei mercati speculativi esterni.</p>
                          </div>
                        </div>
                      </div>

                      <div className="mt-6 pt-4 border-t border-emerald-900/60 flex flex-col sm:flex-row items-center justify-between gap-4">
                        <div className="flex items-center gap-4">
                          <label className="inline-flex items-center gap-2 cursor-pointer text-xs text-slate-300">
                            <input
                              type="checkbox"
                              checked={autoSimulation}
                              onChange={(e) => setAutoSimulation(e.target.checked)}
                              className="accent-emerald-500"
                            />
                            <span>Esegui simulazione automatica (ogni 15 secondi)</span>
                          </label>
                        </div>

                        <button
                          onClick={triggerFormulaTick}
                          disabled={isSimulatingTick}
                          className="bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs px-5 py-2.5 rounded-lg uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer disabled:opacity-50"
                        >
                          <RefreshCw className={`w-4 h-4 ${isSimulatingTick ? 'animate-spin' : ''}`} />
                          Ricalcola Tariffe Adesso
                        </button>
                      </div>

                    </div>
                  </div>

                  {/* ACTIVE GOVERNANCE PROPOSALS VOTE STATION */}
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    
                    {/* SUBMIT NEW ECO-FINANCIAL PROPOSAL FORM */}
                    <div className="bg-[#0b1410] border border-emerald-950 rounded-xl p-5 shadow-lg lg:col-span-1">
                      <h3 className="text-xs font-bold uppercase tracking-widest text-amber-400 border-b border-emerald-950 pb-2 mb-4">
                        Invia Nuova Proposta
                      </h3>

                      <form onSubmit={handleCreateProposal} className="space-y-4 text-xs">
                        <div>
                          <label className="block text-slate-400 mb-1 font-bold">Soggetto Proponente (Popolo / Consiglio)</label>
                          <input
                            type="text"
                            value={newPropProposer}
                            onChange={(e) => setNewPropProposer(e.target.value)}
                            placeholder="Es: Congo Basin Forest Custodians"
                            className="w-full bg-[#050907] border border-emerald-900 rounded p-2 text-slate-100 font-medium"
                            required
                          />
                        </div>

                        <div>
                          <label className="block text-slate-400 mb-1 font-bold">Titolo Proposta Monetaria / Ambientale</label>
                          <input
                            type="text"
                            value={newPropTitle}
                            onChange={(e) => setNewPropTitle(e.target.value)}
                            placeholder="Es: Emissione crediti idrici extra"
                            className="w-full bg-[#050907] border border-emerald-900 rounded p-2 text-slate-100 font-medium"
                            required
                          />
                        </div>

                        <div>
                          <label className="block text-slate-400 mb-1 font-bold">Descrizione e Copertura di Riserva</label>
                          <textarea
                            rows={4}
                            value={newPropDesc}
                            onChange={(e) => setNewPropDesc(e.target.value)}
                            placeholder="Descrivi dettagliatamente come la comunità intende coprire l'emissione con risorse fisiche tangibili..."
                            className="w-full bg-[#050907] border border-emerald-900 rounded p-2 text-slate-100 font-medium"
                            required
                          />
                        </div>

                        <div>
                          <label className="block text-slate-400 mb-1 font-bold">Impatto di Sostenibilità Stimato (Metric)</label>
                          <input
                            type="text"
                            value={newPropImpact}
                            onChange={(e) => setNewPropImpact(e.target.value)}
                            placeholder="Es: +4.2% AQS Value, +1.1% Water Autonomy"
                            className="w-full bg-[#050907] border border-emerald-900 rounded p-2 text-slate-100 font-medium"
                          />
                        </div>

                        <button
                          type="submit"
                          className="w-full bg-emerald-950 text-emerald-400 hover:bg-emerald-900 border border-emerald-800 hover:border-emerald-700 py-2 rounded font-bold uppercase tracking-wider transition-all cursor-pointer"
                        >
                          Pubblica nel Network
                        </button>
                      </form>

                      {propStatusMsg && (
                        <div className="mt-3 p-2 bg-emerald-950/80 border border-emerald-800 text-emerald-300 rounded text-center text-[11px]">
                          {propStatusMsg}
                        </div>
                      )}
                    </div>

                    {/* VOTE LISTING AND CURRENT STATE */}
                    <div className="bg-[#0b1410] border border-emerald-950 rounded-xl p-5 shadow-lg lg:col-span-2 space-y-4">
                      <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-emerald-950 pb-2 flex justify-between items-center">
                        <span>Referendum Democratici di Emissione (Proposte Attive)</span>
                        <span className="text-[10px] text-emerald-400 font-mono">Consenso AI-Supportato</span>
                      </h3>

                      <div className="space-y-4 max-h-[460px] overflow-y-auto pr-1">
                        {state?.proposals.map((prop) => {
                          const totalVotes = prop.votesFor + prop.votesAgainst;
                          const percentFor = totalVotes > 0 ? ((prop.votesFor / totalVotes) * 100).toFixed(1) : '0.0';
                          return (
                            <div key={prop.id} className="bg-[#0e1b14]/50 border border-emerald-950 rounded-lg p-4 space-y-3.5">
                              <div className="flex items-start justify-between gap-4">
                                <div>
                                  <span className={`inline-block px-2 py-0.5 rounded text-[9px] font-mono font-bold mb-1.5 ${
                                    prop.status === 'ACTIVE' 
                                      ? 'bg-amber-950 text-amber-400 border border-amber-900' 
                                      : 'bg-emerald-950 text-emerald-400 border border-emerald-900'
                                  }`}>
                                    Stato: {prop.status}
                                  </span>
                                  <h4 className="text-sm font-bold text-slate-100">{prop.title}</h4>
                                  <p className="text-[11px] text-slate-400 mt-1">Proposta da: <b className="text-slate-300 font-mono">{prop.proposer}</b></p>
                                </div>

                                <div className="text-right shrink-0">
                                  <span className="text-[10px] text-slate-400 font-mono">Impatto AI:</span>
                                  <p className="text-xs text-emerald-400 font-mono font-bold">{prop.impactMetric}</p>
                                </div>
                              </div>

                              <p className="text-xs text-slate-300 leading-relaxed bg-[#050907]/40 p-2.5 rounded border border-emerald-950/80">
                                {prop.description}
                              </p>

                              {/* Voting progress bar */}
                              <div className="space-y-1">
                                <div className="flex justify-between text-[10px] font-mono text-slate-400">
                                  <span>A favore: {prop.votesFor.toLocaleString()} ({percentFor}%)</span>
                                  <span>Contro: {prop.votesAgainst.toLocaleString()}</span>
                                </div>
                                <div className="w-full bg-[#050907] h-2 rounded-full overflow-hidden border border-emerald-950">
                                  <div 
                                    className="bg-emerald-500 h-full transition-all duration-500"
                                    style={{ width: `${percentFor}%` }}
                                  ></div>
                                </div>
                              </div>

                              {/* Interactive actions for voting */}
                              {prop.status === 'ACTIVE' && (
                                <div className="flex items-center gap-2 pt-1 text-xs">
                                  <span className="text-slate-400 text-[10px]">Esprimi Voto Comunitario:</span>
                                  <button
                                    onClick={() => handleVote(prop.id, 'for')}
                                    className="bg-emerald-950 hover:bg-emerald-900 text-emerald-400 px-3 py-1 rounded border border-emerald-800/80 transition-all font-semibold flex items-center gap-1 cursor-pointer"
                                  >
                                    <TrendingUp className="w-3 h-3" />
                                    Approva
                                  </button>
                                  <button
                                    onClick={() => handleVote(prop.id, 'against')}
                                    className="bg-rose-950/60 hover:bg-rose-900/40 text-rose-400 px-3 py-1 rounded border border-rose-900/60 transition-all font-semibold flex items-center gap-1 cursor-pointer"
                                  >
                                    <TrendingDown className="w-3 h-3" />
                                    Opponiti
                                  </button>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>

                  </div>

                </div>
              )}

              {/* TAB 3: SOVEREIGN POPULATION REGISTRY (SPR) */}
              {activeTab === 'registry' && (
                <div className="space-y-6">
                  
                  <div className="bg-[#0b1410] border border-emerald-950 rounded-xl p-5 shadow-lg">
                    <h2 className="text-base font-bold text-amber-400 flex items-center gap-2 mb-2">
                      <Globe className="w-5 h-5 text-emerald-400" />
                      Sovereign Population Registry (SPR)
                    </h2>
                    <p className="text-slate-300 text-xs leading-relaxed">
                      Il registro delle popolazioni sovrane tiene traccia dei gruppi indigenti, comunità autonome e popoli tradizionali che hanno ratificato il trattato SSFN. Ciascun popolo contribuisce con la propria densità demografica ed indice sovrano (calcolato su un mix di sussistenza autonoma, energia verde e capitale umano) al paniere complessivo del <b>P-ISO Sovereign Dollar</b>.
                    </p>
                  </div>

                  {/* SEARCH AND DIRECTORY GRID */}
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    
                    {/* REGISTER NEW POPULATION FORM */}
                    <div className="bg-[#0b1410] border border-emerald-950 rounded-xl p-5 shadow-lg lg:col-span-1">
                      <h3 className="text-xs font-bold uppercase tracking-widest text-amber-400 border-b border-emerald-950 pb-2 mb-4">
                        Registra Nuova Comunità
                      </h3>

                      <form onSubmit={handleRegisterNation} className="space-y-4 text-xs">
                        <div>
                          <label className="block text-slate-400 mb-1 font-bold">Nome Popolo o Alleanza Territoriale</label>
                          <input
                            type="text"
                            value={newNationName}
                            onChange={(e) => setNewNationName(e.target.value)}
                            placeholder="Es: Navajo Solar Sovereignty Council"
                            className="w-full bg-[#050907] border border-emerald-900 rounded p-2 text-slate-100 font-medium font-mono"
                            required
                          />
                        </div>

                        <div>
                          <label className="block text-slate-400 mb-1 font-bold">Continente / Macroregione</label>
                          <select
                            value={newNationRegion}
                            onChange={(e) => setNewNationRegion(e.target.value)}
                            className="w-full bg-[#050907] border border-emerald-900 rounded p-2 text-slate-100 font-medium"
                          >
                            <option value="Africa">Africa</option>
                            <option value="Europe">Europe</option>
                            <option value="Asia">Asia</option>
                            <option value="Americas">Americas</option>
                            <option value="Oceania">Oceania</option>
                            <option value="Indigenous">Popoli indigeni e autonomi</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-slate-400 mb-1 font-bold">Popolazione Rappresentata</label>
                          <input
                            type="number"
                            value={newNationPopulation}
                            onChange={(e) => setNewNationPopulation(e.target.value)}
                            className="w-full bg-[#050907] border border-emerald-900 rounded p-2 text-slate-100 font-mono"
                            required
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="block text-slate-400 mb-1 font-bold">Crescita Demog. (%)</label>
                            <input
                              type="text"
                              value={newNationGrowth}
                              onChange={(e) => setNewNationGrowth(e.target.value)}
                              className="w-full bg-[#050907] border border-emerald-900 rounded p-2 text-slate-100 font-mono"
                            />
                          </div>
                          <div>
                            <label className="block text-slate-400 mb-1 font-bold">Indice Sovrano (0-100)</label>
                            <input
                              type="text"
                              value={newNationIndex}
                              onChange={(e) => setNewNationIndex(e.target.value)}
                              className="w-full bg-[#050907] border border-emerald-900 rounded p-2 text-slate-100 font-mono"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-slate-400 mb-1 font-bold">Descrizione e Focus di Sviluppo</label>
                          <textarea
                            rows={3}
                            value={newNationDesc}
                            onChange={(e) => setNewNationDesc(e.target.value)}
                            placeholder="Descrivi la risorsa principale che la comunità conferisce al network..."
                            className="w-full bg-[#050907] border border-emerald-900 rounded p-2 text-slate-100 font-medium"
                          />
                        </div>

                        <button
                          type="submit"
                          className="w-full bg-amber-400 hover:bg-amber-500 text-black py-2 rounded font-bold uppercase tracking-wider transition-all cursor-pointer"
                        >
                          Inoltra Registrazione SPR
                        </button>
                      </form>

                      {nationStatusMsg && (
                        <div className="mt-3 p-2 bg-emerald-950/80 border border-emerald-800 text-emerald-300 rounded text-center text-[11px]">
                          {nationStatusMsg}
                        </div>
                      )}
                    </div>

                    {/* DIRECTORY LISTING */}
                    <div className="bg-[#0b1410] border border-emerald-950 rounded-xl p-5 shadow-lg lg:col-span-2 space-y-4">
                      
                      {/* Search and category filters */}
                      <div className="flex flex-col sm:flex-row gap-3">
                        <div className="relative flex-1">
                          <Search className="absolute left-2.5 top-2.5 w-4 h-4 text-slate-500" />
                          <input
                            type="text"
                            placeholder="Cerca per nome o descrizione..."
                            value={nationSearch}
                            onChange={(e) => setNationSearch(e.target.value)}
                            className="w-full bg-[#050907] border border-emerald-950 rounded px-3 py-2 pl-9 text-xs focus:outline-none focus:ring-1 focus:ring-amber-400"
                          />
                        </div>

                        <select
                          value={nationRegionFilter}
                          onChange={(e) => setNationRegionFilter(e.target.value)}
                          className="bg-[#050907] border border-emerald-950 rounded px-3 py-2 text-xs text-slate-300 focus:outline-none focus:ring-1 focus:ring-amber-400"
                        >
                          <option value="ALL">Tutte le Regioni</option>
                          <option value="Africa">Africa</option>
                          <option value="Europe">Europe</option>
                          <option value="Asia">Asia</option>
                          <option value="Americas">Americas</option>
                          <option value="Oceania">Oceania</option>
                          <option value="Indigenous">Popoli indigeni e autonomi</option>
                        </select>
                      </div>

                      <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1">
                        {filteredNations.map((nat) => (
                          <div key={nat.id} className="bg-[#0e1b14]/40 border border-emerald-950/80 rounded-lg p-4 hover:border-emerald-900 transition-colors">
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                              <div>
                                <h4 className="text-sm font-bold text-slate-100 flex items-center gap-1.5">
                                  {nat.name}
                                </h4>
                                <span className="text-[10px] text-emerald-400 font-mono font-bold tracking-wide uppercase">
                                  Regione: {nat.region}
                                </span>
                              </div>

                              <div className="flex items-center gap-4 text-xs text-slate-400 font-mono">
                                <div>
                                  <span className="text-[10px] text-slate-500 block">Popolazione</span>
                                  <span className="text-slate-200 font-bold">{nat.population.toLocaleString()}</span>
                                </div>
                                <div>
                                  <span className="text-[10px] text-slate-500 block">Indice Sovrano</span>
                                  <span className="text-amber-400 font-bold">{nat.sovereignIndex}/100</span>
                                </div>
                                <div>
                                  <span className="text-[10px] text-slate-500 block">Crescita</span>
                                  <span className="text-emerald-400 font-bold">+{nat.growthRate}%</span>
                                </div>
                              </div>
                            </div>

                            <p className="text-xs text-slate-300 mt-2.5 leading-relaxed italic bg-[#050907]/30 p-2 rounded border border-emerald-950/50">
                              {nat.description}
                            </p>
                          </div>
                        ))}

                        {filteredNations.length === 0 && (
                          <p className="text-center text-slate-500 text-xs py-8 italic">Nessun popolo trovato per i parametri specificati.</p>
                        )}
                      </div>
                    </div>

                  </div>

                </div>
              )}

              {/* TAB 4: P-ISO CENTRAL AUTHORITY (PICA) & SGRS */}
              {activeTab === 'authority' && (
                <div className="space-y-6">
                  
                  {/* CENTRAL BANK DETAILS */}
                  <div className="bg-[#0b1410] border border-emerald-950 rounded-xl p-6 shadow-lg">
                    <h2 className="text-base font-bold text-amber-400 flex items-center gap-2 mb-3">
                      <ShieldCheck className="w-5 h-5 text-emerald-400" />
                      P-ISO Central Authority (PICA)
                    </h2>
                    
                    <p className="text-slate-300 text-xs leading-relaxed">
                      L&apos;<b>Autorità Centrale PICA</b> è l&apos;ente regolatore preposto alla vigilanza dell&apos;Ecosistema Sovrano. Coordina le politiche monetarie, garantisce gli standard di riserva globali del <b>SIPSE Global Reserve System (SGRS)</b>, contrasta le attività speculative e vigila sull&apos;emissione del debito e del credito sovrano.
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-6 text-xs text-center font-mono">
                      <div className="bg-[#050907] border border-emerald-950 p-3 rounded-lg">
                        <p className="text-slate-500 uppercase text-[9px]">Target Volatilità</p>
                        <p className="text-lg font-bold text-slate-100 mt-1">4.5% Max</p>
                      </div>
                      <div className="bg-[#050907] border border-emerald-950 p-3 rounded-lg">
                        <p className="text-slate-500 uppercase text-[9px]">Target Inflazione</p>
                        <p className="text-lg font-bold text-slate-100 mt-1">2.0% Annuo</p>
                      </div>
                      <div className="bg-[#050907] border border-emerald-950 p-3 rounded-lg">
                        <p className="text-slate-500 uppercase text-[9px]">Stato Audit Riserve</p>
                        <p className="text-lg font-bold text-emerald-400 mt-1">Certificato 100%</p>
                      </div>
                      <div className="bg-[#050907] border border-emerald-950 p-3 rounded-lg">
                        <p className="text-slate-500 uppercase text-[9px]">Cap totale circolazione</p>
                        <p className="text-lg font-bold text-amber-400 mt-1">4.5 Triliardi §P</p>
                      </div>
                    </div>
                  </div>

                  {/* RESERVE BACKING SCHEME & MINT BURN ACTIONS */}
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    
                    {/* BACKING PIE CHART & LIST */}
                    <div className="bg-[#0b1410] border border-emerald-950 rounded-xl p-5 shadow-lg lg:col-span-2">
                      <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-emerald-950 pb-2 mb-4">
                        SIPSE Global Reserve Backing (SGRS)
                      </h3>

                      <p className="text-xs text-slate-300 mb-4 leading-relaxed">
                        Ciascun P-ISO Sovereign Dollar (§P) è coperto da una combinazione ponderata di beni primari reali di sussistenza depositati o vincolati in loco nei rispettivi territori sovrani nazionali.
                      </p>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2 text-xs">
                          <div className="bg-emerald-950/20 p-2.5 rounded border border-emerald-950 flex justify-between">
                            <span className="font-bold flex items-center gap-1.5 text-slate-200">
                              <span className="w-2.5 h-2.5 bg-yellow-400 rounded-full inline-block"></span>
                              Riserva Oro Fisico (GLS / GLX)
                            </span>
                            <span className="font-mono text-slate-300 font-bold">25.5%</span>
                          </div>
                          <div className="bg-emerald-950/20 p-2.5 rounded border border-emerald-950 flex justify-between">
                            <span className="font-bold flex items-center gap-1.5 text-slate-200">
                              <span className="w-2.5 h-2.5 bg-blue-400 rounded-full inline-block"></span>
                              Bacini Idrici e Idrogeologici (AQS / WTR)
                            </span>
                            <span className="font-mono text-slate-300 font-bold">22.0%</span>
                          </div>
                          <div className="bg-emerald-950/20 p-2.5 rounded border border-emerald-950 flex justify-between">
                            <span className="font-bold flex items-center gap-1.5 text-slate-200">
                              <span className="w-2.5 h-2.5 bg-green-500 rounded-full inline-block"></span>
                              Biomassa Forestale e Carbonio (FRS / CRBX)
                            </span>
                            <span className="font-mono text-slate-300 font-bold">18.5%</span>
                          </div>
                          <div className="bg-emerald-950/20 p-2.5 rounded border border-emerald-950 flex justify-between">
                            <span className="font-bold flex items-center gap-1.5 text-slate-200">
                              <span className="w-2.5 h-2.5 bg-orange-400 rounded-full inline-block"></span>
                              Griglie Energetiche Solari (ENS / SLS)
                            </span>
                            <span className="font-mono text-slate-300 font-bold">15.0%</span>
                          </div>
                          <div className="bg-emerald-950/20 p-2.5 rounded border border-emerald-950 flex justify-between">
                            <span className="font-bold flex items-center gap-1.5 text-slate-200">
                              <span className="w-2.5 h-2.5 bg-red-400 rounded-full inline-block"></span>
                              Riserve Minerali Critiche (MNS / LTH)
                            </span>
                            <span className="font-mono text-slate-300 font-bold">19.0%</span>
                          </div>
                        </div>

                        {/* Interactive abstract SVG representing backings */}
                        <div className="bg-[#050907] rounded-lg p-4 flex flex-col items-center justify-center border border-emerald-950">
                          <svg className="w-36 h-36" viewBox="0 0 100 100">
                            <circle cx="50" cy="50" r="40" fill="none" stroke="#0e2617" strokeWidth="8" />
                            <circle cx="50" cy="50" r="40" fill="none" stroke="#fbbf24" strokeWidth="8" strokeDasharray="64 251.2" strokeDashoffset="0" />
                            <circle cx="50" cy="50" r="40" fill="none" stroke="#60a5fa" strokeWidth="8" strokeDasharray="55 251.2" strokeDashoffset="-64" />
                            <circle cx="50" cy="50" r="40" fill="none" stroke="#10b981" strokeWidth="8" strokeDasharray="46 251.2" strokeDashoffset="-119" />
                            <circle cx="50" cy="50" r="40" fill="none" stroke="#fb923c" strokeWidth="8" strokeDasharray="86 251.2" strokeDashoffset="-165" />
                            <circle cx="50" cy="50" r="22" fill="#070e0a" />
                            <text x="50" y="53" textAnchor="middle" fill="#fbbf24" fontSize="9" fontWeight="bold" fontFamily="monospace">SGRS</text>
                          </svg>
                          <span className="text-[10px] text-slate-500 mt-3 font-mono">Pondicazione delle Riserve Reali</span>
                        </div>
                      </div>
                    </div>

                    {/* INTERACTIVE MINT/BURN INTERACTION BLOCK */}
                    <div className="bg-[#0b1410] border border-emerald-950 rounded-xl p-5 shadow-lg lg:col-span-1">
                      <div className="flex items-center gap-1.5 border-b border-emerald-950 pb-2 mb-4">
                        <Lock className="w-4 h-4 text-amber-400" />
                        <h3 className="text-xs font-bold uppercase tracking-widest text-amber-400">
                          PICA Policy Console
                        </h3>
                      </div>

                      <p className="text-[11px] text-slate-400 mb-4">
                        Simula l&apos;intervento correttivo di emissione (Mint) o ritiro (Burn) della riserva per ripristinare il target di volatilità prestabilito.
                      </p>

                      <form onSubmit={handlePicaOperation} className="space-y-4 text-xs font-medium">
                        <div>
                          <label className="block text-slate-400 mb-1.5">Asset da Regolare</label>
                          <select
                            value={picaAssetCode}
                            onChange={(e) => setPicaAssetCode(e.target.value)}
                            className="w-full bg-[#050907] border border-emerald-900 rounded p-2 text-slate-100 font-mono"
                          >
                            {state?.currencies.map(c => (
                              <option key={c.code} value={c.code}>{c.code} - {c.name}</option>
                            ))}
                          </select>
                        </div>

                        <div>
                          <label className="block text-slate-400 mb-1.5">Azione di Regolazione</label>
                          <div className="grid grid-cols-2 gap-2 bg-emerald-950/40 p-1 rounded">
                            <button
                              type="button"
                              onClick={() => setPicaActionType('MINT')}
                              className={`py-1 rounded font-bold text-xs ${picaActionType === 'MINT' ? 'bg-emerald-500 text-black' : 'text-slate-400'}`}
                            >
                              EMETTI (Mint)
                            </button>
                            <button
                              type="button"
                              onClick={() => setPicaActionType('BURN')}
                              className={`py-1 rounded font-bold text-xs ${picaActionType === 'BURN' ? 'bg-rose-500 text-white' : 'text-slate-400'}`}
                            >
                              RITIRA (Burn)
                            </button>
                          </div>
                        </div>

                        <div>
                          <label className="block text-slate-400 mb-1.5">Quantità Token</label>
                          <input
                            type="number"
                            value={picaAmount}
                            onChange={(e) => setPicaAmount(e.target.value)}
                            className="w-full bg-[#050907] border border-emerald-900 rounded p-2 text-slate-100 font-mono"
                            required
                          />
                        </div>

                        <button
                          type="submit"
                          className="w-full bg-amber-400 hover:bg-amber-500 text-black py-2 rounded font-bold uppercase tracking-wider text-xs transition-all cursor-pointer"
                        >
                          Esegui Azione PICA
                        </button>
                      </form>

                      {picaStatusMsg && (
                        <div className="mt-3 p-2.5 bg-emerald-950/80 border border-emerald-800 text-emerald-300 rounded text-center text-[10px] font-mono leading-relaxed">
                          {picaStatusMsg}
                        </div>
                      )}
                    </div>

                  </div>

                </div>
              )}

              {/* TAB 5: WORDPRESS INTEGRATION KIT */}
              {activeTab === 'shortcodes' && (
                <div className="space-y-6">
                  
                  <div className="bg-[#0b1410] border border-emerald-950 rounded-xl p-5 shadow-lg">
                    <h2 className="text-base font-bold text-amber-400 flex items-center gap-2 mb-2">
                      <Code className="w-5 h-5 text-emerald-400" />
                      WordPress Integration Kit & Shortcodes
                    </h2>
                    
                    <p className="text-slate-300 text-xs leading-relaxed">
                      Hai bisogno di connettere questo ecosistema finanziario sovrano direttamente al portale principale <a href="https://sipsesovereign.org/" target="_blank" rel="noopener noreferrer" className="underline text-emerald-400">sipsesovereign.org</a> o a un altro sito associato? 
                      Usa il nostro simulatore per generare i corretti shortcode WordPress, configura le opzioni desiderate e visualizza un&apos;anteprima interattiva immediata del widget.
                    </p>
                  </div>

                  {/* CONFIGURATOR AND LIVE PREVIEW */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                    
                    {/* CONFIGURATOR COLUMN */}
                    <div className="bg-[#0b1410] border border-emerald-950 rounded-xl p-5 shadow-lg lg:col-span-4 space-y-4 text-xs">
                      <h3 className="text-xs font-bold uppercase tracking-widest text-amber-400 border-b border-emerald-950 pb-2 mb-2">
                        Configura Widget
                      </h3>

                      <div>
                        <label className="block text-slate-400 mb-1.5 font-bold">Seleziona Shortcode Base</label>
                        <select
                          value={selectedShortcode}
                          onChange={(e: any) => setSelectedShortcode(e.target.value)}
                          className="w-full bg-[#050907] border border-emerald-900 rounded p-2 text-slate-100 font-mono"
                        >
                          <option value="[piso_exchange]">[piso_exchange] - Ticker Valute P-ISO</option>
                          <option value="[pnrx_exchange]">[pnrx_exchange] - Ticker Risorse PNRX</option>
                          <option value="[sipse_dashboard]">[sipse_dashboard] - Mini Dashboard Globale</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-slate-400 mb-1.5 font-bold">Stile Grafico (Tema)</label>
                        <div className="grid grid-cols-3 gap-2 bg-[#050907] p-1 rounded border border-emerald-950">
                          <button
                            type="button"
                            onClick={() => setScTheme('dark')}
                            className={`py-1 rounded text-center transition-colors ${scTheme === 'dark' ? 'bg-emerald-800 text-white font-bold' : 'text-slate-400'}`}
                          >
                            Dark Cyber
                          </button>
                          <button
                            type="button"
                            onClick={() => setScTheme('light')}
                            className={`py-1 rounded text-center transition-colors ${scTheme === 'light' ? 'bg-amber-400 text-black font-bold' : 'text-slate-400'}`}
                          >
                            Clean Light
                          </button>
                          <button
                            type="button"
                            onClick={() => setScTheme('gold')}
                            className={`py-1 rounded text-center transition-colors ${scTheme === 'gold' ? 'bg-yellow-600 text-black font-bold' : 'text-slate-400'}`}
                          >
                            Royal Gold
                          </button>
                        </div>
                      </div>

                      <div>
                        <label className="block text-slate-400 mb-1.5 font-bold">Numero massimo elementi</label>
                        <input
                          type="number"
                          min="3"
                          max="15"
                          value={scLimit}
                          onChange={(e) => setScLimit(parseInt(e.target.value) || 5)}
                          className="w-full bg-[#050907] border border-emerald-900 rounded p-2 text-slate-100 font-mono"
                        />
                      </div>

                      <div className="bg-[#050907] p-3 rounded-lg border border-emerald-950 space-y-2.5">
                        <p className="text-[10px] text-slate-400 uppercase tracking-widest font-mono font-bold">Codice Generato per WordPress</p>
                        
                        <div className="bg-[#0b1410] border border-emerald-900 p-2 rounded text-slate-100 font-mono text-[11px] select-all break-all">
                          {selectedShortcode === '[piso_exchange]' && `[piso_exchange theme="${scTheme}" limit="${scLimit}" show_chart="true"]`}
                          {selectedShortcode === '[pnrx_exchange]' && `[pnrx_exchange theme="${scTheme}" limit="${scLimit}"]`}
                          {selectedShortcode === '[sipse_dashboard]' && `[sipse_dashboard theme="${scTheme}" show_map="true"]`}
                        </div>

                        <button
                          onClick={handleCopyShortcode}
                          className="w-full py-1.5 bg-emerald-950 hover:bg-emerald-900 text-emerald-400 border border-emerald-800 rounded font-bold uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer transition-colors"
                        >
                          {copiedCode ? (
                            <>
                              <Check className="w-4 h-4 text-emerald-400" />
                              Copiato!
                            </>
                          ) : (
                            <>
                              <Copy className="w-4 h-4" />
                              Copia negli Appunti
                            </>
                          )}
                        </button>
                      </div>
                    </div>

                    {/* LIVE WIDGET PREVIEW COLUMN */}
                    <div className="bg-[#121c15]/20 border border-dashed border-emerald-800 rounded-xl p-6 lg:col-span-8 space-y-4">
                      <div className="flex justify-between items-center pb-2 border-b border-emerald-950">
                        <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                          Anteprima Reale del Widget (Rendering WordPress)
                        </span>
                        <span className="text-[9px] text-emerald-500 font-mono">Simulato Gutenberg Block v1.0</span>
                      </div>

                      {/* Mock WordPress Theme container */}
                      <div className={`p-6 rounded-lg transition-all border ${
                        scTheme === 'dark' 
                          ? 'bg-[#070e0a] text-slate-200 border-emerald-900/80 shadow-2xl' 
                          : scTheme === 'light'
                            ? 'bg-slate-50 text-slate-800 border-slate-300 shadow-xl'
                            : 'bg-gradient-to-br from-[#12140e] to-[#2e2912] text-[#fcd34d] border-yellow-600/40 shadow-2xl'
                      }`}>
                        
                        {/* Title of container inside WP theme */}
                        <div className="mb-4">
                          <p className={`text-[9px] uppercase tracking-widest ${scTheme === 'light' ? 'text-slate-500' : 'text-slate-400'}`}>
                            SIPSE SOVEREIGN PORTAL INTEGRATION
                          </p>
                          <h4 className="text-sm font-bold mt-1">
                            {selectedShortcode === '[piso_exchange]' && 'P-ISO Sovereign Exchange Rates'}
                            {selectedShortcode === '[pnrx_exchange]' && 'People&apos;s Natural Resources (PNRX)'}
                            {selectedShortcode === '[sipse_dashboard]' && 'SIPSE Sovereign Network Operations'}
                          </h4>
                        </div>

                        {/* RENDER EMBEDDED SHORTCODE CONTENT */}
                        {selectedShortcode === '[piso_exchange]' && (
                          <div className="space-y-2">
                            {pIsoCurrencies.slice(0, scLimit).map((curr) => {
                              const isPositive = parseFloat(curr.changePercent) >= 0;
                              return (
                                <div 
                                  key={curr.code} 
                                  className={`p-2.5 rounded flex items-center justify-between text-xs ${
                                    scTheme === 'dark' ? 'bg-[#0e1b14] border border-emerald-950' :
                                    scTheme === 'light' ? 'bg-white border border-slate-200 shadow-sm' :
                                    'bg-yellow-950/20 border border-yellow-600/20'
                                  }`}
                                >
                                  <div className="flex items-center gap-2">
                                    <span className={`font-mono font-extrabold text-[10px] px-1.5 py-0.5 rounded ${
                                      scTheme === 'light' ? 'bg-slate-200 text-slate-800' : 'bg-emerald-950 text-emerald-400'
                                    }`}>
                                      {curr.code}
                                    </span>
                                    <span className="font-semibold">{curr.name}</span>
                                  </div>

                                  <div className="text-right font-mono">
                                    <span className="font-bold mr-3">§P {parseFloat(curr.valuePsd).toFixed(3)}</span>
                                    <span className={isPositive ? 'text-emerald-500' : 'text-rose-500'}>
                                      {isPositive ? '▲' : '▼'} {curr.changePercent}%
                                    </span>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}

                        {selectedShortcode === '[pnrx_exchange]' && (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            {pnrxAssets.slice(0, scLimit).map((curr) => {
                              return (
                                <div 
                                  key={curr.code} 
                                  className={`p-2 rounded flex items-center justify-between text-xs ${
                                    scTheme === 'dark' ? 'bg-[#0e1b14] border border-emerald-950' :
                                    scTheme === 'light' ? 'bg-white border border-slate-200 shadow-sm' :
                                    'bg-yellow-950/20 border border-yellow-600/20'
                                  }`}
                                >
                                  <span className="font-bold">{curr.name}</span>
                                  <span className="font-mono text-[11px] text-right">
                                    §P {parseFloat(curr.valuePsd).toFixed(2)}
                                  </span>
                                </div>
                              );
                            })}
                          </div>
                        )}

                        {selectedShortcode === '[sipse_dashboard]' && (
                          <div className="space-y-4">
                            <div className="grid grid-cols-3 gap-2 text-center text-[11px] font-mono">
                              <div className={`p-2 rounded ${scTheme === 'light' ? 'bg-slate-200' : 'bg-[#0a120e] border border-emerald-950'}`}>
                                <span className="block text-[9px] text-slate-400 uppercase">POPULATION</span>
                                <b className="text-xs">482,000,000</b>
                              </div>
                              <div className={`p-2 rounded ${scTheme === 'light' ? 'bg-slate-200' : 'bg-[#0a120e] border border-emerald-950'}`}>
                                <span className="block text-[9px] text-slate-400 uppercase">SOVEREIGN INDEX</span>
                                <b className="text-xs text-amber-500">83.6/100</b>
                              </div>
                              <div className={`p-2 rounded ${scTheme === 'light' ? 'bg-slate-200' : 'bg-[#0a120e] border border-emerald-950'}`}>
                                <span className="block text-[9px] text-slate-400 uppercase">INFLATION TARGET</span>
                                <b className="text-xs text-emerald-400">2.0%</b>
                              </div>
                            </div>

                            <div className={`h-24 rounded-lg flex items-center justify-center border text-[11px] font-mono ${
                              scTheme === 'light' ? 'bg-slate-100 border-slate-300' : 'bg-emerald-950/20 border-emerald-900/60'
                            }`}>
                              <Globe className="w-5 h-5 text-emerald-400 mr-2 animate-spin" />
                              <span>127 Popoli Aderenti Connessi in Tempo Reale</span>
                            </div>
                          </div>
                        )}

                        {/* Footer indicator of WordPress Plugin */}
                        <div className="mt-4 pt-3 border-t border-slate-700/40 text-[10px] flex justify-between text-slate-500">
                          <span>SIPSE Sovereign Plugin v1.0.4</span>
                          <span>sipsesovereign.org API Link</span>
                        </div>
                      </div>

                      <div className="p-3 bg-emerald-950/30 border border-emerald-900/50 rounded-lg text-xs">
                        <p className="font-semibold text-slate-200">Come si installa sul tuo tema WordPress?</p>
                        <ol className="list-decimal list-inside text-[11px] text-slate-400 mt-1 space-y-1">
                          <li>Scarica o integra il plugin ufficiale SIPSE Sovereign.</li>
                          <li>Incolla lo shortcode generato in una pagina, articolo o blocco Gutenberg.</li>
                          <li>Il client interroga in background lo stato monetario tramite l&apos;API SSFN.</li>
                        </ol>
                      </div>

                    </div>

                  </div>

                </div>
              )}

              {/* TAB 6: REST API DOCUMENTATION */}
              {activeTab === 'api' && (
                <div className="space-y-6">
                  
                  <div className="bg-[#0b1410] border border-emerald-950 rounded-xl p-5 shadow-lg">
                    <h2 className="text-base font-bold text-amber-400 flex items-center gap-2 mb-2">
                      <FileCode className="w-5 h-5 text-emerald-500" />
                      REST API Sovereign Explorer
                    </h2>
                    
                    <p className="text-slate-300 text-xs leading-relaxed">
                      L&apos;ecosistema finanziario SSFN fornisce un set completo di API JSON pubbliche e private per consentire alle comunità, agli sviluppatori e ai sistemi regionali di leggere in tempo reale le quotazioni, i registri demografici ed eseguire ordini approvati.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 font-mono text-xs">
                    
                    {/* API DIRECTORY AND TEST */}
                    <div className="bg-[#0b1410] border border-emerald-950 rounded-xl p-5 shadow-lg space-y-4">
                      <h3 className="text-xs font-bold uppercase tracking-widest text-amber-400 border-b border-emerald-950 pb-2">
                        Endpoints Disponibili
                      </h3>

                      <div className="space-y-3">
                        <div className="p-3 bg-emerald-950/30 rounded border border-emerald-950">
                          <span className="bg-emerald-500 text-black px-1.5 py-0.5 rounded text-[10px] font-bold">GET</span>
                          <span className="text-slate-200 ml-2 font-bold">/api/sipse-state</span>
                          <p className="text-slate-400 text-[10px] mt-1.5 font-sans">Ritorna lo stato completo dell&apos;ecosistema: valute, merci, popoli, ordini e parametri monetari di base.</p>
                        </div>

                        <div className="p-3 bg-emerald-950/30 rounded border border-emerald-950">
                          <span className="bg-blue-500 text-white px-1.5 py-0.5 rounded text-[10px] font-bold">POST</span>
                          <span className="text-slate-200 ml-2 font-bold">/api/sipse-state</span>
                          <p className="text-slate-400 text-[10px] mt-1.5 font-sans">Inoltra ordini monetari, registra nuove comunità, vota i decreti monetari ed esegue l&apos;algoritmo AI.</p>
                        </div>
                      </div>

                      {/* Mock Curl code */}
                      <div className="space-y-1.5">
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Esempio Richiesta curl</p>
                        <pre className="bg-[#050907] border border-emerald-950 rounded p-3 text-emerald-400 overflow-x-auto text-[11px] leading-relaxed">
{`curl -X POST \\
  https://sipsesovereign.org/api/sipse-state \\
  -H 'Content-Type: application/json' \\
  -d '{
    "action": "buy_sell",
    "type": "BUY",
    "currencyCode": "AQS",
    "amount": "100"
  }'`}
                        </pre>
                      </div>
                    </div>

                    {/* LIVE JSON STATE PREVIEW CONTAINER */}
                    <div className="bg-[#0b1410] border border-emerald-950 rounded-xl p-5 shadow-lg space-y-3">
                      <div className="flex justify-between items-center border-b border-emerald-950 pb-2">
                        <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400">
                          Payload di Risposta Real-Time (JSON)
                        </h3>
                        <span className="text-[9px] text-emerald-500 animate-pulse">Live Dynamic</span>
                      </div>

                      <div className="bg-[#050907] border border-emerald-950 rounded-lg p-3 text-[11px] text-emerald-400 overflow-auto max-h-[420px] scrollbar-thin">
                        <pre>
                          {JSON.stringify({
                            success: true,
                            timestamp: new Date().toISOString(),
                            ecosystem: "SIPSE Sovereign Financial Network v1.0",
                            metrics: state?.metrics || {
                              totalNationsCount: 127,
                              representedPopulation: 482000000,
                              avgSovereignIndex: 83.6
                            },
                            sample_currencies: state?.currencies.slice(0, 3) || []
                          }, null, 2)}
                        </pre>
                      </div>
                    </div>

                  </div>

                </div>
              )}

            </div>

          </div>
        )}
      </main>

      {/* 5. FOOTER */}
      <footer className="mt-16 bg-[#040805] border-t border-emerald-950 py-12 text-slate-400 text-xs">
        <div className="max-w-[1400px] mx-auto px-4 space-y-8">
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="space-y-3">
              <h4 className="font-bold text-slate-200">SIPSE SSFN v1.0</h4>
              <p className="text-[11px] leading-relaxed">
                Rete finanziaria digitale sovrana costruita su riserve naturali tangibili locali e democrazia partecipativa diretta.
              </p>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-bold text-slate-200">Ecosistema Base</h4>
              <ul className="space-y-1.5 text-[11px] font-mono">
                <li><span className="text-amber-500">§P</span> P-ISO Sovereign Dollar</li>
                <li>PSX Sovereign Exchange</li>
                <li>PNRX Natural Resources Ex.</li>
                <li>SPR Sovereign Pop. Registry</li>
              </ul>
            </div>

            <div className="space-y-3">
              <h4 className="font-bold text-slate-200">Integrazione WordPress</h4>
              <ul className="space-y-1.5 text-[11px] font-mono">
                <li>[piso_exchange]</li>
                <li>[pnrx_exchange]</li>
                <li>[sipse_dashboard]</li>
              </ul>
            </div>

            <div className="space-y-3">
              <h4 className="font-bold text-slate-200">Disclaimer Legale</h4>
              <p className="text-[10px] leading-relaxed text-slate-500 font-sans">
                Le quotazioni SIPSE rappresentano valori ufficiali interni dell&apos;ecosistema SIPSE Sovereign e non costituiscono strumenti finanziari regolamentati o quotazioni dei mercati internazionali. Tutte le quotazioni e le transazioni effettuate su questa piattaforma simulata servono a scopi illustrativi e didattici relativi all&apos;infrastruttura di <a href="https://sipsesovereign.org/" target="_blank" rel="noopener noreferrer" className="underline text-emerald-500">sipsesovereign.org</a>.
              </p>
            </div>
          </div>

          <div className="pt-8 border-t border-emerald-950/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-500">
            <p>© 2026 SIPSE Sovereign Financial Network (SSFN). Tutti i diritti sono riservati ai popoli aderenti.</p>
            <div className="flex gap-4">
              <a href="https://sipsesovereign.org/" target="_blank" rel="noopener noreferrer" className="hover:text-emerald-400 transition-colors">
                Sito Ufficiale
              </a>
              <span>|</span>
              <span className="text-amber-400 font-mono">Ecosystem Protocol Suite v1.0</span>
            </div>
          </div>

        </div>
      </footer>

    </div>
  );
}
