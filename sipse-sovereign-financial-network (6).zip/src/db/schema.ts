import { pgTable, serial, varchar, integer, numeric, text, timestamp, boolean, bigint } from 'drizzle-orm/pg-core';

// Sovereign Population Registry (SPR)
export const sovereignNations = pgTable('sovereign_nations', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 255 }).notNull().unique(),
  region: varchar('region', { length: 100 }).notNull(), // Africa, Europe, Asia, Americas, Oceania, Indigenous
  population: bigint('population', { mode: 'number' }).notNull(),
  growthRate: numeric('growth_rate', { precision: 5, scale: 2 }).notNull().default('2.10'),
  sovereignIndex: numeric('sovereign_index', { precision: 5, scale: 2 }).notNull().default('83.60'),
  description: text('description'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Currencies & Assets (PSX and PNRX)
export const currencies = pgTable('currencies', {
  code: varchar('code', { length: 10 }).primaryKey(), // AQS, AGR, etc. / WTR, LTH, etc.
  name: varchar('name', { length: 150 }).notNull(),
  category: varchar('category', { length: 50 }).notNull(), // "P-ISO" or "PNRX"
  baseAsset: text('base_asset').notNull(), // "water & water systems", "lithium", etc.
  valuePsd: numeric('value_psd', { precision: 16, scale: 4 }).notNull(),
  capPsd: bigint('cap_psd', { mode: 'number' }), // e.g. 180 billion
  originalValue: numeric('original_value', { precision: 16, scale: 4 }).notNull(),
  changePercent: numeric('change_percent', { precision: 8, scale: 2 }).notNull().default('0.00'),
  lastUpdated: timestamp('last_updated').defaultNow().notNull(),
});

// Digital Wallet Network
export const walletBalances = pgTable('wallet_balances', {
  id: serial('id').primaryKey(),
  walletAddress: varchar('wallet_address', { length: 100 }).notNull(),
  currencyCode: varchar('currency_code', { length: 10 }).notNull(),
  balance: numeric('balance', { precision: 20, scale: 4 }).notNull().default('0.0000'),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Trading log
export const orders = pgTable('orders', {
  id: serial('id').primaryKey(),
  walletAddress: varchar('wallet_address', { length: 100 }).notNull(),
  type: varchar('type', { length: 10 }).notNull(), // BUY or SELL
  currencyCode: varchar('currency_code', { length: 10 }).notNull(),
  amount: numeric('amount', { precision: 20, scale: 4 }).notNull(),
  pricePsd: numeric('price_psd', { precision: 16, scale: 4 }).notNull(),
  totalPsd: numeric('total_psd', { precision: 20, scale: 4 }).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Governance Proposals (AI and community voted)
export const governanceProposals = pgTable('governance_proposals', {
  id: serial('id').primaryKey(),
  title: varchar('title', { length: 255 }).notNull(),
  description: text('description').notNull(),
  proposer: varchar('proposer', { length: 100 }).notNull(),
  status: varchar('status', { length: 50 }).notNull().default('ACTIVE'), // ACTIVE, PASSED, FAILED
  votesFor: integer('votes_for').notNull().default(0),
  votesAgainst: integer('votes_against').notNull().default(0),
  impactMetric: varchar('impact_metric', { length: 255 }).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Historical Prices for Charts
export const priceHistory = pgTable('price_history', {
  id: serial('id').primaryKey(),
  currencyCode: varchar('currency_code', { length: 10 }).notNull(),
  price: numeric('price', { precision: 16, scale: 4 }).notNull(),
  timestamp: timestamp('timestamp').defaultNow().notNull(),
});
