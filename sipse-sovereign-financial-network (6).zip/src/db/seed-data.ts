import { db } from './index';
import { currencies, sovereignNations, walletBalances, governanceProposals, priceHistory } from './schema';
import { sql } from 'drizzle-orm';

export interface CurrencySeed {
  code: string;
  name: string;
  category: string;
  baseAsset: string;
  valuePsd: string;
  capPsd?: number;
  originalValue: string;
}

export const INITIAL_CURRENCIES: CurrencySeed[] = [
  // P-ISO Currencies (PSX)
  { code: 'AQS', name: 'Aqua Sovereign', category: 'P-ISO', baseAsset: 'Acqua e sistemi idrici', valuePsd: '0.9100', capPsd: 180000000000, originalValue: '0.9100' },
  { code: 'AGR', name: 'Agro Sovereign', category: 'P-ISO', baseAsset: 'Produzione agricola', valuePsd: '1.1300', capPsd: 210000000000, originalValue: '1.1300' },
  { code: 'ENS', name: 'Energy Sovereign', category: 'P-ISO', baseAsset: 'Energia', valuePsd: '2.4100', capPsd: 420000000000, originalValue: '2.4100' },
  { code: 'MNS', name: 'Mineral Sovereign', category: 'P-ISO', baseAsset: 'Minerali', valuePsd: '1.6300', capPsd: 150000000000, originalValue: '1.6300' },
  { code: 'FRS', name: 'Forest Sovereign', category: 'P-ISO', baseAsset: 'Foreste', valuePsd: '0.7400', capPsd: 95000000000, originalValue: '0.7400' },
  { code: 'SLS', name: 'Solar Sovereign', category: 'P-ISO', baseAsset: 'Energia solare', valuePsd: '1.9200', capPsd: 130000000000, originalValue: '1.9200' },
  { code: 'BDS', name: 'Biodiversity Sovereign', category: 'P-ISO', baseAsset: 'Biodiversità', valuePsd: '1.3400', capPsd: 85000000000, originalValue: '1.3400' },
  { code: 'OCS', name: 'Ocean Sovereign', category: 'P-ISO', baseAsset: 'Risorse marine', valuePsd: '2.8200', capPsd: 240000000000, originalValue: '2.8200' },
  { code: 'TCS', name: 'Technology Sovereign', category: 'P-ISO', baseAsset: 'Innovazione e tecnologia', valuePsd: '3.2400', capPsd: 190000000000, originalValue: '3.2400' },
  { code: 'HCS', name: 'Human Capital Sovereign', category: 'P-ISO', baseAsset: 'Capitale umano e lavoro', valuePsd: '1.9700', capPsd: 110000000000, originalValue: '1.9700' },
  { code: 'CRS', name: 'Carbon Sovereign', category: 'P-ISO', baseAsset: 'Crediti carbonio', valuePsd: '0.6600', capPsd: 70000000000, originalValue: '0.6600' },
  { code: 'GLS', name: 'Gold Sovereign', category: 'P-ISO', baseAsset: 'Oro', valuePsd: '4.3800', capPsd: 350000000000, originalValue: '4.3800' },
  { code: 'EAS', name: 'Earth Sovereign', category: 'P-ISO', baseAsset: 'Risorse territoriali', valuePsd: '5.1200', capPsd: 500000000000, originalValue: '5.1200' },
  { code: 'CPS', name: 'Cultural Sovereign', category: 'P-ISO', baseAsset: 'Patrimonio culturale', valuePsd: '1.0900', capPsd: 60000000000, originalValue: '1.0900' },
  { code: 'FDS', name: 'Food Sovereign', category: 'P-ISO', baseAsset: 'Sicurezza alimentare', valuePsd: '1.4800', capPsd: 125000000000, originalValue: '1.4800' },

  // People's Natural Resources Exchange (PNRX) assets
  { code: 'WTR', name: 'Acqua dolce', category: 'PNRX', baseAsset: 'Risorse idriche dirette', valuePsd: '73.2400', originalValue: '73.2400' },
  { code: 'LTH', name: 'Litio', category: 'PNRX', baseAsset: 'Riserva mineraria Litio', valuePsd: '324.5100', originalValue: '324.5100' },
  { code: 'COP', name: 'Rame', category: 'PNRX', baseAsset: 'Riserve di rame industriale', valuePsd: '132.6300', originalValue: '132.6300' },
  { code: 'GLX', name: 'Oro Minerale', category: 'PNRX', baseAsset: 'Riserve auree fisiche', valuePsd: '3362.1400', originalValue: '3362.1400' },
  { code: 'SLX', name: 'Argento Minerale', category: 'PNRX', baseAsset: 'Riserve argentee fisiche', valuePsd: '43.2100', originalValue: '43.2100' },
  { code: 'TIM', name: 'Legname', category: 'PNRX', baseAsset: 'Massa forestale sostenibile', valuePsd: '89.7700', originalValue: '89.7700' },
  { code: 'GAS', name: 'Gas Naturale', category: 'PNRX', baseAsset: 'Idrocarburi gassosi puliti', valuePsd: '157.8800', originalValue: '157.8800' },
  { code: 'OIL', name: 'Petrolio Greggio', category: 'PNRX', baseAsset: 'Combustibili fossili regolati', valuePsd: '98.4500', originalValue: '98.4500' },
  { code: 'SUN', name: 'Credito Energia Solare', category: 'PNRX', baseAsset: 'Produzione solare GW/h', valuePsd: '78.1400', originalValue: '78.1400' },
  { code: 'BIOX', name: 'Biodiversità forestale', category: 'PNRX', baseAsset: 'Ettari foresta incontaminata', valuePsd: '111.0800', originalValue: '111.0800' },
  { code: 'CRBX', name: 'Certificati Carbonio', category: 'PNRX', baseAsset: 'Tonnellate CO2 assorbite', valuePsd: '40.1500', originalValue: '40.1500' },
  { code: 'AGRX', name: 'Terreni Agricoli', category: 'PNRX', baseAsset: 'Ettari coltivati biologici', valuePsd: '148.5400', originalValue: '148.5400' },
];

export const INITIAL_NATIONS = [
  // Africa (29 total, representing representative items to make up 127 total)
  { name: 'Kush Kingdom Restoration Union', region: 'Africa', population: 24000000, growthRate: '2.40', sovereignIndex: '85.20', description: 'Unione di popoli lungo la valle del Nilo per la sovranità delle risorse idriche e solari.' },
  { name: 'Sovereign Sahara Alliance', region: 'Africa', population: 18500000, growthRate: '2.60', sovereignIndex: '81.40', description: 'Federazione di comunita nomadi e stanziali dedita allo sviluppo solare e idrico.' },
  { name: 'Congo Basin Forest Custodians', region: 'Africa', population: 42000000, growthRate: '2.80', sovereignIndex: '88.10', description: 'Custodi sovrani della foresta pluviale del Congo, emettitori dei forest credits.' },
  { name: 'Zambezi River Eco-Tribe', region: 'Africa', population: 11200000, growthRate: '2.20', sovereignIndex: '79.80', description: 'Popoli uniti nella tutela del bacino fluviale dello Zambesi.' },
  { name: 'Great Rift Sovereign Assembly', region: 'Africa', population: 31000000, growthRate: '2.50', sovereignIndex: '84.00', description: 'Associazione di popoli della Rift Valley incentrata su biodiversità e agroecologia.' },
  { name: 'Nama & San Sovereign Council', region: 'Africa', population: 4500000, growthRate: '1.90', sovereignIndex: '89.50', description: 'Antichi popoli del deserto con sovranità ancestrale sui giacimenti minerali di litio.' },

  // Europe (18 total, representative)
  { name: 'Sami Sovereign Council', region: 'Europe', population: 140000, growthRate: '0.80', sovereignIndex: '94.20', description: 'Consiglio sovrano del popolo Sami nel nord Europa, focalizzato sulla conservazione artica.' },
  { name: 'Celtia Autonomous Confederation', region: 'Europe', population: 8900000, growthRate: '1.10', sovereignIndex: '86.40', description: 'Associazione culturale e territoriale per l agricoltura sostenibile e l energia marina.' },
  { name: 'Occitania Sovereign Commune', region: 'Europe', population: 3400000, growthRate: '0.90', sovereignIndex: '82.70', description: 'Comunità basata sul patrimonio storico, agricolo e cooperativismo decentralizzato.' },
  { name: 'Alps Free Water Protectors', region: 'Europe', population: 6100000, growthRate: '1.00', sovereignIndex: '91.80', description: 'Unione montana per la salvaguardia dei ghiacciai e riserve idriche montane europee.' },

  // Asia (31 total, representative)
  { name: 'Indus Valley Agro-Sovereigns', region: 'Asia', population: 64000000, growthRate: '2.10', sovereignIndex: '78.50', description: 'Rete di agricoltori biologici e custodi sementiere indipendenti.' },
  { name: 'Siberian Forest Free Alliance', region: 'Asia', population: 9200000, growthRate: '1.20', sovereignIndex: '83.30', description: 'Popoli indigeni della taiga siberiana uniti per la conservazione delle foreste primitive.' },
  { name: 'Tibetan Plateau Ecologic Union', region: 'Asia', population: 7800000, growthRate: '1.40', sovereignIndex: '87.90', description: 'Unione spirituale e geografica a tutela delle sorgenti dei maggiori fiumi asiatici.' },
  { name: 'Sumatra Biodiversity Guild', region: 'Asia', population: 15400000, growthRate: '2.00', sovereignIndex: '81.20', description: 'Cooperative di piccoli produttori a salvaguardia della foresta pluviale e specie protette.' },
  { name: 'Kyrgyz Nomadic Pastoralist Council', region: 'Asia', population: 3800000, growthRate: '1.80', sovereignIndex: '85.60', description: 'Gestione collettiva dei pascoli d alta quota e risorse idriche glaciali.' },

  // Americas (24 total, representative)
  { name: 'Lakota Sovereign Nation Council', region: 'Americas', population: 250000, growthRate: '1.90', sovereignIndex: '91.20', description: 'Comunità nativa americana impegnata nello sviluppo dell energia eolica e solare autonoma.' },
  { name: 'Amazon Sacred Headwaters Alliance', region: 'Americas', population: 24000000, growthRate: '2.90', sovereignIndex: '93.50', description: 'Alleanza di 32 popoli indigeni dell Ecuador e Perù custodi di 30 milioni di ettari di foresta.' },
  { name: 'Andean Ayllu Confederation', region: 'Americas', population: 19500000, growthRate: '1.80', sovereignIndex: '85.90', description: 'Rete comunitaria per la conservazione dei microclimi montani e coltivazioni ancestrali.' },
  { name: 'Guarani Aquifer Protectors', region: 'Americas', population: 14200000, growthRate: '2.30', sovereignIndex: '80.10', description: 'Associazione transfrontaliera per la sovranità e protezione di uno dei maggiori acquiferi mondiali.' },

  // Oceania (11 total, representative)
  { name: 'Maori Sovereign Whanau Network', region: 'Oceania', population: 850000, growthRate: '1.70', sovereignIndex: '92.40', description: 'Consorzio neozelandese basato sui principi di Kaitiakitanga (custodia della terra e degli oceani).' },
  { name: 'Melanesian Blue Guardians', region: 'Oceania', population: 6800000, growthRate: '2.50', sovereignIndex: '83.90', description: 'Alleanza delle isole del Pacifico per la tutela della barriera corallina e risorse marine.' },
  { name: 'Aboriginal Dreamtime Caretakers', region: 'Oceania', population: 980000, growthRate: '2.20', sovereignIndex: '90.70', description: 'Consiglio dei clan australiani nativi con titoli di possesso consuetudinario del territorio arido.' },

  // Indigenous & Autonomi Generici (14 total, representative aggregate)
  { name: 'Global Sovereign Nomad Assembly', region: 'Indigenous', population: 12000000, growthRate: '2.10', sovereignIndex: '88.00', description: 'Rete intercontinentale di popoli senza fissa dimora con sovranità digitale e identitaria.' },
  { name: 'Archipelago of Free Thinkers', region: 'Indigenous', population: 3500000, growthRate: '1.50', sovereignIndex: '89.20', description: 'Comunità intenzionali focalizzate su innovazione open-source e micro-griglie ecologiche.' }
];

export const INITIAL_PROPOSALS = [
  {
    title: 'Finanziamento Sovrano Griglia Solare Sahara',
    description: 'Emissione di 150 milioni di SLS (Solar Sovereign) per finanziare l installazione di micro-impianti fotovoltaici a gestione comunitaria nel deserto del Sahara occidentale, riducendo la dipendenza da fonti fossili importate.',
    proposer: 'Sovereign Sahara Alliance',
    status: 'ACTIVE',
    votesFor: 12450,
    votesAgainst: 3120,
    impactMetric: '+15.2% Solar Grid Autonomy, +2.1% SLS Currency Backing'
  },
  {
    title: 'Fondo di Conservazione Ghiacciai Alpini',
    description: 'Richiesta di stanziamento di 50 milioni di AQS (Aqua Sovereign) per l implementazione di schermi riflettenti e sistemi di monitoraggio cooperativo delle sorgenti idriche montane sulle Alpi centrali.',
    proposer: 'Alps Free Water Protectors',
    status: 'ACTIVE',
    votesFor: 8900,
    votesAgainst: 1250,
    impactMetric: '+8.4% Water Flow Stabilization, +1.2% AQS Value'
  },
  {
    title: 'Digitalizzazione Registro Demografico Ancestrale (SPR)',
    description: 'Integrazione di sistemi biometrici sovrani decentralizzati nel Sovereign Population Registry (SPR) per consentire l auto-certificazione dell identità senza passare da agenzie governative esterne.',
    proposer: 'Maori Sovereign Whanau Network',
    status: 'PASSED',
    votesFor: 25400,
    votesAgainst: 850,
    impactMetric: '+100% Identity Control, +4.5% Network Security'
  }
];

export async function seedIfEmpty() {
  try {
    // 1. Check if currencies are already initialized
    const existingCurrencies = await db.select().from(currencies).limit(1);
    
    if (existingCurrencies.length === 0) {
      console.log('Database empty! Seeding initial SIPSE Sovereign Ecosystem data...');

      // Seed Currencies & Assets
      for (const curr of INITIAL_CURRENCIES) {
        await db.insert(currencies).values({
          code: curr.code,
          name: curr.name,
          category: curr.category,
          baseAsset: curr.baseAsset,
          valuePsd: curr.valuePsd,
          capPsd: curr.capPsd || null,
          originalValue: curr.originalValue,
          changePercent: '0.00',
        });

        // Add 5 historical price points to start chart with some realistic data
        const origVal = parseFloat(curr.valuePsd);
        for (let i = 0; i < 5; i++) {
          const variance = (Math.sin(i) * 0.05 + (Math.random() - 0.5) * 0.02) * origVal;
          const histPrice = (origVal + variance).toFixed(4);
          const time = new Date(Date.now() - (5 - i) * 3600 * 1000); // hours ago
          await db.insert(priceHistory).values({
            currencyCode: curr.code,
            price: histPrice,
            timestamp: time,
          });
        }
      }

      // Seed Sovereign Nations
      for (const nation of INITIAL_NATIONS) {
        await db.insert(sovereignNations).values({
          name: nation.name,
          region: nation.region,
          population: nation.population,
          growthRate: nation.growthRate,
          sovereignIndex: nation.sovereignIndex,
          description: nation.description,
        });
      }

      // Seed Governance Proposals
      for (const prop of INITIAL_PROPOSALS) {
        await db.insert(governanceProposals).values({
          title: prop.title,
          description: prop.description,
          proposer: prop.proposer,
          status: prop.status,
          votesFor: prop.votesFor,
          votesAgainst: prop.votesAgainst,
          impactMetric: prop.impactMetric,
        });
      }

      // Seed Initial Digital Wallet Balances
      // Provide initial funding of some currencies to "SIPSE-SOV-7719-2026"
      const walletAddr = 'SIPSE-SOV-7719-2026';
      const initialBalances = [
        { code: 'PSD', amount: '12500.0000' },
        { code: 'AQS', amount: '1500.0000' },
        { code: 'ENS', amount: '450.0000' },
        { code: 'SLS', amount: '800.0000' },
        { code: 'GLS', amount: '120.0000' },
        { code: 'WTR', amount: '50.0000' },
        { code: 'LTH', amount: '12.0000' },
        { code: 'SUN', amount: '250.0000' },
      ];

      for (const bal of initialBalances) {
        await db.insert(walletBalances).values({
          walletAddress: walletAddr,
          currencyCode: bal.code,
          balance: bal.amount,
        });
      }

      console.log('Seeding successfully completed!');
    } else {
      console.log('Database already has data. Skipping seed.');
    }
  } catch (error) {
    console.error('Error seeding database:', error);
  }
}
